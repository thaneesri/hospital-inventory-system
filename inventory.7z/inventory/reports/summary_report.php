<?php
// File: /reports/summary_report.php

// 1. เรียกใช้ไฟล์ที่จำเป็น
require_once '../includes/auth_check.php'; // ตรวจสอบการ Login
require_once '../includes/database_functions.php'; // ฟังก์ชันจัดการฐานข้อมูล

// 2. ตั้งค่าตัวกรอง (Filter) เริ่มต้น หรือรับค่าจาก URL
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01'); // ถ้าไม่มีค่า ให้เป็นวันแรกของเดือนปัจจุบัน
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d'); // ถ้าไม่มีค่า ให้เป็นวันปัจจุบัน
$status = isset($_GET['status']) ? $_GET['status'] : 'All'; // ถ้าไม่มีค่า ให้เป็น 'All' (ทั้งหมด)

// 3. ดึงข้อมูลรายงานจากฐานข้อมูลตามตัวกรอง
$reportResult = getRequisitionReport($conn, $startDate, $endDate, $status);

// 4. ตั้งค่าหัวข้อของหน้าเว็บ และเรียกใช้ Header
$pageTitle = "รายงานสรุปการเบิกจ่าย";
require_once '../admin/partials/header.php';
?>

<!-- ส่วนของฟอร์มสำหรับกรองข้อมูล -->
<div class="bg-white p-6 rounded-lg shadow-md mb-8">
    <form action="summary_report.php" method="get" class="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
        <!-- Input สำหรับเลือกวันที่เริ่มต้น -->
        <div>
            <label for="start_date" class="block text-sm font-medium text-gray-700">วันที่เริ่มต้น</label>
            <input type="date" name="start_date" id="start_date" value="<?php echo htmlspecialchars($startDate); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
        </div>
        <!-- Input สำหรับเลือกวันที่สิ้นสุด -->
        <div>
            <label for="end_date" class="block text-sm font-medium text-gray-700">วันที่สิ้นสุด</label>
            <input type="date" name="end_date" id="end_date" value="<?php echo htmlspecialchars($endDate); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
        </div>
        <!-- Dropdown สำหรับเลือกสถานะ -->
        <div>
            <label for="status" class="block text-sm font-medium text-gray-700">สถานะ</label>
            <select name="status" id="status" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                <option value="All" <?php if($status == 'All') echo 'selected'; ?>>ทั้งหมด</option>
                <option value="Pending" <?php if($status == 'Pending') echo 'selected'; ?>>รออนุมัติ</option>
                <option value="Approved" <?php if($status == 'Approved') echo 'selected'; ?>>อนุมัติแล้ว</option>
                <option value="Dispensed" <?php if($status == 'Dispensed') echo 'selected'; ?>>จ่ายแล้ว</option>
                <option value="Rejected" <?php if($status == 'Rejected') echo 'selected'; ?>>ปฏิเสธ</option>
            </select>
        </div>
        <!-- ปุ่มสำหรับส่งฟอร์มเพื่อกรองข้อมูล -->
        <div>
            <button type="submit" class="w-full py-2 px-4 rounded-md text-white bg-indigo-600 hover:bg-indigo-700">แสดงรายงาน</button>
        </div>
        <!-- ปุ่มสำหรับส่งออกข้อมูลเป็น Excel -->
        <div>
            <a href="export_handler.php?report_type=summary&start_date=<?php echo $startDate; ?>&end_date=<?php echo $endDate; ?>&status=<?php echo $status; ?>" 
               class="w-full block text-center py-2 px-4 rounded-md text-white bg-green-600 hover:bg-green-700">
               ส่งออกเป็น Excel
            </a>
        </div>
    </form>
</div>

<!-- ส่วนของตารางแสดงผลรายงาน -->
<div class="bg-white p-6 rounded-lg shadow-md">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left">เลขที่ใบเบิก</th>
                <th class="px-6 py-3 text-left">วันที่เบิก</th>
                <th class="px-6 py-3 text-left">ผู้เบิก</th>
                <th class="px-6 py-3 text-left">สถานะ</th>
                <th class="px-6 py-3 text-right">มูลค่ารวม (บาท)</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $grandTotal = 0; // ตัวแปรสำหรับเก็บยอดรวมทั้งหมด
            // ตรวจสอบว่ามีข้อมูลหรือไม่
            if ($reportResult && $reportResult->num_rows > 0) {
                // วนลูปแสดงข้อมูลแต่ละแถว
                while($row = $reportResult->fetch_assoc()) {
                    $grandTotal += $row['TotalValue']; // เพิ่มมูลค่าในแถวปัจจุบันเข้าไปในยอดรวม
                    echo "<tr>";
                    echo "<td class='px-6 py-4'>#" . str_pad($row['RequisitionID'], 6, "0", STR_PAD_LEFT) . "</td>";
                    echo "<td class='px-6 py-4'>" . date("d/m/Y", strtotime($row['RequisitionDate'])) . "</td>";
                    echo "<td class='px-6 py-4'>" . htmlspecialchars($row['RequesterName']) . "</td>";
                    echo "<td class='px-6 py-4'>" . htmlspecialchars($row['Status']) . "</td>";
                    echo "<td class='px-6 py-4 text-right'>" . number_format($row['TotalValue'], 2) . "</td>";
                    echo "</tr>";
                }
            } else {
                // ถ้าไม่พบข้อมูล
                echo "<tr><td colspan='5' class='text-center p-4'>ไม่พบข้อมูลในช่วงที่เลือก</td></tr>";
            }
            ?>
        </tbody>
        <tfoot class="bg-gray-100">
            <!-- แถวสำหรับแสดงยอดรวมทั้งหมด -->
            <tr>
                <td colspan="4" class="px-6 py-3 text-right font-bold">ยอดรวมทั้งหมด</td>
                <td class="px-6 py-3 text-right font-bold"><?php echo number_format($grandTotal, 2); ?></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php
// 5. เรียกใช้ Footer
require_once '../admin/partials/footer.php';
?>
