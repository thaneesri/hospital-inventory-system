<?php
// File: /reports/export_handler.php

// --- เริ่มการบัฟเฟอร์ Output ---
// ส่วนนี้สำคัญมาก: จะเก็บ output ทั้งหมดไว้ในหน่วยความจำก่อน
// เพื่อป้องกันไม่ให้มีข้อความ error หรือช่องว่างหลุดออกไปปนกับไฟล์ Excel
ob_start();

// 1. เรียกใช้ไฟล์ที่จำเป็น
require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

// 2. เรียกใช้ไลบรารี PhpSpreadsheet ด้วย Path ที่แม่นยำขึ้น
require_once __DIR__ . '/../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Font;

// 3. ตรวจสอบประเภทรายงาน
if (!isset($_GET['report_type'])) {
    die("Invalid report type.");
}

$reportType = $_GET['report_type'];
$filename = $reportType . "_" . date('Y-m-d') . ".xlsx";

// 4. สร้างอ็อบเจ็กต์ Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// 5. จัดการข้อมูลตามประเภทรายงาน
switch ($reportType) {
    case 'all_items':
        $sheet->setTitle('รายการยาทั้งหมด');
        $headers = [
            'รหัสสินค้า (ItemCode)', 'ชื่อรายการ (ItemName)', 'ประเภท (ItemType)', 'กลุ่มยา (Category)', 
            'รูปแบบยา (Formulation)', 'ขนาดบรรจุ (PackageSize)', 'ความแรง (Strength)', 
            'หน่วยนับ (Unit)', 'ราคา (Price)', 'จุดสั่งซื้อ (ReorderPoint)'
        ];
        $sheet->fromArray($headers, NULL, 'A1');
        $sheet->getStyle('A1:J1')->getFont()->setBold(true);

        $result = getAllItems($conn);
        if ($result && $result->num_rows > 0) {
            $rowIndex = 2;
            while ($row = $result->fetch_assoc()) {
                $dataRow = [
                    $row['ItemCode'], $row['ItemName'], $row['ItemType'], $row['Category'], 
                    $row['Formulation'], $row['PackageSize'], $row['Strength'], 
                    $row['Unit'], $row['Price'], $row['ReorderPoint']
                ];
                $sheet->fromArray($dataRow, NULL, 'A' . $rowIndex);
                $rowIndex++;
            }
        }
        
        foreach (range('A', 'J') as $columnID) {
            $sheet->getColumnDimension($columnID)->setAutoSize(true);
        }
        break;

    // สามารถเพิ่ม case อื่นๆ สำหรับรายงานประเภทอื่นได้ที่นี่
    // case 'summary': ...
    // case 'inventory_value': ...
    // case 'inventory_on_hand': ...

    default:
        $sheet->setCellValue('A1', 'Invalid Report Type');
        break;
}

// --- ล้างข้อมูลบัฟเฟอร์ทั้งหมดก่อนส่งไฟล์ ---
ob_end_clean();

// 6. ตั้งค่า Header สำหรับดาวน์โหลดไฟล์ .xlsx
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

// 7. สร้าง Writer และส่งไฟล์ไปยัง Output
try {
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
} catch (\PhpOffice\PhpSpreadsheet\Exception $e) {
    // กรณีเกิดข้อผิดพลาดในการสร้างไฟล์
    die('Error creating file: ' . $e->getMessage());
}

exit();
?>
