<?php
// File : reports/inventory_on_hand_report.php

require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

$reportResult = getInventoryOnHandReport($conn);

$pageTitle = "รายงานสินค้าคงคลัง";
require_once '../admin/partials/header.php';
?>

<div class="bg-white p-6 rounded-lg shadow-md">
    <div class="flex justify-end mb-4">
        <a href="export_handler.php?report_type=inventory_on_hand" 
           class="py-2 px-4 rounded-md text-white bg-green-600 hover:bg-green-700">
           ส่งออกเป็น Excel
        </a>
    </div>

    <div class="overflow-x-auto">
        <table id="inventoryTable" class="min-w-full">
            <thead>
                <tr>
                    <th>ชื่อรายการ</th>
                    <th>Lot Number</th>
                    <th>วันหมดอายุ</th>
                    <th class="text-right">จำนวนคงเหลือ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($reportResult && $reportResult->num_rows > 0) {
                    while($row = $reportResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td><div class='font-medium'>" . htmlspecialchars($row['ItemName']) . "</div><div class='text-sm text-gray-500'>" . htmlspecialchars($row['ItemCode']) . "</div></td>";
                        echo "<td>" . htmlspecialchars($row['LotNumber']) . "</td>";
                        echo "<td>" . ($row['ExpiryDate'] ? date("d/m/Y", strtotime($row['ExpiryDate'])) : '-') . "</td>";
                        echo "<td class='text-right font-bold'>" . number_format($row['Quantity']) . " " . htmlspecialchars($row['Unit']) . "</td>";
                        echo "</tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../admin/partials/footer.php'; ?>

<!-- สคริปต์สำหรับ Datatable -->
<link href="https://cdn.jsdelivr.net/npm/vanilla-datatables@latest/dist/vanilla-dataTables.min.css" rel="stylesheet" type="text/css">
<script src="https://cdn.jsdelivr.net/npm/vanilla-datatables@latest/dist/vanilla-dataTables.min.js" type="text/javascript"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const dataTable = new DataTable("#inventoryTable", {
            perPage: 25,
            labels: {
                placeholder: "ค้นหา...",
                perPage: "{select} รายการต่อหน้า",
                noRows: "ไม่พบข้อมูล",
                info: "แสดง {start} ถึง {end} จาก {rows} รายการ",
            }
        });
    });
</script>
