<?php
// File: /reports/inventory_value_report.php

// 1. เรียกใช้ไฟล์ที่จำเป็น
require_once '../includes/auth_check.php'; // ตรวจสอบการ Login
require_once '../includes/database_functions.php'; // ฟังก์ชันจัดการฐานข้อมูล

// 2. ดึงข้อมูลรายงานมูลค่าคงคลังจากฐานข้อมูล
$reportResult = getInventoryValueReport($conn);

// 3. ตั้งค่าหัวข้อของหน้าเว็บ และเรียกใช้ Header
$pageTitle = "รายงานมูลค่าคงคลัง";
require_once '../admin/partials/header.php';
?>

<!-- ส่วนแสดงผลของหน้ารายงาน -->
<div class="bg-white p-6 rounded-lg shadow-md">
    <!-- ปุ่มสำหรับส่งออกข้อมูลเป็น Excel -->
    <div class="flex justify-end mb-4">
        <a href="export_handler.php?report_type=inventory_value" 
           class="py-2 px-4 rounded-md text-white bg-green-600 hover:bg-green-700">
           ส่งออกเป็น Excel
        </a>
    </div>

    <!-- ตารางแสดงผลรายงาน -->
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left">รหัสสินค้า</th>
                <th class="px-6 py-3 text-left">ชื่อรายการ</th>
                <th class="px-6 py-3 text-right">ราคา/หน่วย</th>
                <th class="px-6 py-3 text-right">จำนวนคงเหลือ</th>
                <th class="px-6 py-3 text-right">มูลค่ารวม (บาท)</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $grandTotal = 0; // ตัวแปรสำหรับเก็บมูลค่ารวมทั้งหมด
            // ตรวจสอบว่ามีข้อมูลหรือไม่
            if ($reportResult && $reportResult->num_rows > 0) {
                // วนลูปแสดงข้อมูลแต่ละแถว
                while($row = $reportResult->fetch_assoc()) {
                    $grandTotal += $row['TotalValue']; // เพิ่มมูลค่าในแถวปัจจุบันเข้าไปในยอดรวม
                    echo "<tr>";
                    echo "<td class='px-6 py-4'>" . htmlspecialchars($row['ItemCode']) . "</td>";
                    echo "<td class='px-6 py-4'>" . htmlspecialchars($row['ItemName']) . "</td>";
                    echo "<td class='px-6 py-4 text-right'>" . number_format($row['Price'], 2) . "</td>";
                    echo "<td class='px-6 py-4 text-right'>" . number_format($row['CurrentStock']) . " " . htmlspecialchars($row['Unit']) . "</td>";
                    echo "<td class='px-6 py-4 text-right'>" . number_format($row['TotalValue'], 2) . "</td>";
                    echo "</tr>";
                }
            } else {
                // ถ้าไม่พบข้อมูล
                echo "<tr><td colspan='5' class='text-center p-4'>ไม่พบข้อมูลสต็อกสินค้า</td></tr>";
            }
            ?>
        </tbody>
        <tfoot class="bg-gray-100">
            <!-- แถวสำหรับแสดงมูลค่ารวมทั้งหมด -->
            <tr>
                <td colspan="4" class="px-6 py-3 text-right font-bold">มูลค่าคงคลังรวมทั้งหมด</td>
                <td class="px-6 py-3 text-right font-bold"><?php echo number_format($grandTotal, 2); ?></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php
// 4. เรียกใช้ Footer
require_once '../admin/partials/footer.php';
?>
