<?php
// File: /requisition/my_requisitions.php

require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

// ดึงข้อมูลใบเบิกของผู้ใช้ที่ login อยู่
$requisitionsResult = getRequisitionsByUserId($conn, $_SESSION['user_id']);

$pageTitle = "รายการเบิกของฉัน";
require_once '../admin/partials/header.php';
?>

<div class="bg-white p-6 rounded-lg shadow-md">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-semibold text-gray-700">ประวัติการเบิกทั้งหมด</h2>
        <a href="create_requisition.php" class="py-2 px-4 rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
            + สร้างใบเบิกใหม่
        </a>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">เลขที่ใบเบิก</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">วันที่เบิก</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">สถานะ</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ผู้อนุมัติ</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php
                if ($requisitionsResult && $requisitionsResult->num_rows > 0) {
                    while($row = $requisitionsResult->fetch_assoc()) {
                        // ตั้งค่าสีตามสถานะ
                        $statusColor = 'text-gray-500';
                        switch ($row['Status']) {
                            case 'Pending': $statusColor = 'text-yellow-500'; break;
                            case 'Approved': $statusColor = 'text-green-500'; break;
                            case 'Rejected': $statusColor = 'text-red-500'; break;
                            case 'Dispensed': $statusColor = 'text-blue-500'; break;
                        }

                        echo "<tr>";
                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm font-medium'>#" . str_pad($row['RequisitionID'], 6, "0", STR_PAD_LEFT) . "</td>";
                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm'>" . date("d/m/Y H:i", strtotime($row['RequisitionDate'])) . "</td>";
                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm font-bold " . $statusColor . "'>" . htmlspecialchars($row['Status']) . "</td>";
                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm'>" . ($row['ApproverName'] ? htmlspecialchars($row['ApproverName']) : '-') . "</td>";
                        echo "<td class='px-6 py-4 whitespace-nowrap text-right text-sm font-medium'>";
                        echo "<a href='#' class='text-indigo-600 hover:text-indigo-900'>ดูรายละเอียด</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center p-4 text-sm text-gray-500'>ยังไม่มีประวัติการเบิก</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php
require_once '../admin/partials/footer.php';
?>
