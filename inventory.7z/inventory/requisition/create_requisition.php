<?php
// File: /requisition/create_requisition.php

require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_requisition'])) {
    $requesterId = $_SESSION['user_id'];
    $itemsArray = [];

    if (isset($_POST['stock_id']) && is_array($_POST['stock_id'])) {
        for ($i = 0; $i < count($_POST['stock_id']); $i++) {
            $stockId = $_POST['stock_id'][$i];
            $itemId = $_POST['item_id'][$i];
            $quantity = $_POST['quantity'][$i];

            if (!empty($stockId) && !empty($itemId) && !empty($quantity) && $quantity > 0) {
                $itemsArray[] = ['stockId' => $stockId, 'itemId' => $itemId, 'quantity' => $quantity];
            }
        }
    }

    if (!empty($itemsArray)) {
        $result = createRequisition($conn, $requesterId, $itemsArray);
        if ($result === true) {
            $message = "<div class='bg-green-100 p-3 rounded'>สร้างใบเบิกสำเร็จ!</div>";
        } else {
            $message = "<div class='bg-red-100 p-3 rounded'>เกิดข้อผิดพลาด: " . htmlspecialchars($result) . "</div>";
        }
    } else {
        $message = "<div class='bg-yellow-100 p-3 rounded'>กรุณาเลือกรายการที่ต้องการเบิกอย่างน้อย 1 รายการ</div>";
    }
}

// ดึงข้อมูลสต็อกทั้งหมดที่มีของ
$activeStockLots = getActiveStockLots($conn);

$pageTitle = "สร้างใบเบิกใหม่";
require_once '../admin/partials/header.php';
?>

<!-- ส่วนหน้าหลัก -->
<div class="bg-white p-6 rounded-lg shadow-md max-w-5xl mx-auto">
    <?php echo $message; ?>
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-semibold">รายการที่ต้องการเบิก</h2>
        <button type="button" id="openStockModalBtn" class="py-2 px-4 rounded-md text-white bg-blue-600 hover:bg-blue-700">
            + เลือกสินค้าจากสต็อก
        </button>
    </div>
    <form action="create_requisition.php" method="post">
        <div id="item-rows-container" class="space-y-2">
            <!-- แถวรายการที่เลือกจะถูกเพิ่มที่นี่ -->
        </div>
        <div class="mt-6 text-right border-t pt-4">
            <button type="submit" name="submit_requisition" class="py-2 px-6 rounded-md text-white bg-indigo-600 hover:bg-indigo-700 font-bold">ส่งใบเบิก</button>
        </div>
    </form>
</div>

<!-- Modal สำหรับเลือกสินค้าจากสต็อก -->
<div id="stockModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-semibold">เลือกสินค้าจากสต็อก</h3>
            <button id="closeStockModalBtn" class="text-gray-500 hover:text-gray-800">&times;</button>
        </div>
        <div class="overflow-x-auto">
            <table id="stockDataTable" class="min-w-full">
                <thead>
                    <tr>
                        <th>ชื่อรายการ</th>
                        <th>Lot Number</th>
                        <th>วันหมดอายุ</th>
                        <th class="text-right">คงเหลือ</th>
                        <th data-sortable="false">เลือก</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($lot = $activeStockLots->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($lot['ItemName']); ?></td>
                            <td><?php echo htmlspecialchars($lot['LotNumber']); ?></td>
                            <td><?php echo $lot['ExpiryDate'] ? date("d/m/Y", strtotime($lot['ExpiryDate'])) : '-'; ?></td>
                            <td class="text-right"><?php echo number_format($lot['Quantity']); ?></td>
                            <td>
                                <button type="button" class="select-stock-btn py-1 px-3 bg-green-500 text-white rounded text-xs"
                                        data-stock-id="<?php echo $lot['StockID']; ?>"
                                        data-item-id="<?php echo $lot['ItemID']; ?>"
                                        data-item-name="<?php echo htmlspecialchars($lot['ItemName']); ?>"
                                        data-lot-number="<?php echo htmlspecialchars($lot['LotNumber']); ?>"
                                        data-max-qty="<?php echo $lot['Quantity']; ?>">
                                    เลือก
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- สคริปต์สำหรับ Datatable และ Modal -->
<link href="https://cdn.jsdelivr.net/npm/vanilla-datatables@latest/dist/vanilla-dataTables.min.css" rel="stylesheet" type="text/css">
<script src="https://cdn.jsdelivr.net/npm/vanilla-datatables@latest/dist/vanilla-dataTables.min.js" type="text/javascript"></script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const modal = document.getElementById('stockModal');
    const openBtn = document.getElementById('openStockModalBtn');
    const closeBtn = document.getElementById('closeStockModalBtn');
    const container = document.getElementById('item-rows-container');

    // --- Modal Logic ---
    openBtn.addEventListener('click', () => modal.classList.remove('hidden'));
    closeBtn.addEventListener('click', () => modal.classList.add('hidden'));
    window.addEventListener('click', (e) => {
        if (e.target == modal) {
            modal.classList.add('hidden');
        }
    });

    // --- Datatable Logic ---
    const stockTable = new DataTable("#stockDataTable", {
        perPage: 10,
        labels: {
            placeholder: "ค้นหาชื่อยา หรือ Lot Number...",
            perPage: "{select} รายการต่อหน้า",
            noRows: "ไม่พบข้อมูล",
            info: "แสดง {start} ถึง {end} จาก {rows} รายการ",
        }
    });

    // --- Add Item Logic ---
    stockTable.table.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('select-stock-btn')) {
            const btn = e.target;
            const stockId = btn.dataset.stockId;
            
            // ตรวจสอบว่ามีรายการนี้อยู่แล้วหรือไม่
            if (container.querySelector(`input[name='stock_id[]'][value='${stockId}']`)) {
                alert('คุณได้เลือก Lot นี้ไปแล้ว');
                return;
            }

            // เพิ่มแถวใหม่ในฟอร์มหลัก
            addNewRow(btn.dataset);
            modal.classList.add('hidden');
        }
    });

    function addNewRow(data) {
        const newRowHTML = `
            <div class="item-row grid grid-cols-12 gap-3 items-center border-b pb-2">
                <div class="col-span-7">
                    <input type="hidden" name="stock_id[]" value="${data.stockId}">
                    <input type="hidden" name="item_id[]" value="${data.itemId}">
                    <p class="font-medium text-sm">${data.itemName}</p>
                    <p class="text-xs text-gray-500">Lot: ${data.lotNumber}</p>
                </div>
                <div class="col-span-4">
                    <input type="number" name="quantity[]" value="1" min="1" max="${data.maxQty}" 
                           class="w-full border-gray-300 rounded-md text-right" required>
                </div>
                <div class="col-span-1">
                    <button type="button" class="remove-item-btn p-2 text-white bg-red-500 hover:bg-red-600 rounded-md">&times;</button>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', newRowHTML);
    }

    // --- Remove Item Logic ---
    container.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('remove-item-btn')) {
            e.target.closest('.item-row').remove();
        }
    });
});
</script>

<?php require_once '../admin/partials/footer.php'; ?>
