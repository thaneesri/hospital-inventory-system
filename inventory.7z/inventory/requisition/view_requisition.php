<?php
// File: requisition/view_requisition.php

require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

if (!isset($_GET['id'])) {
    header("Location: my_requisitions.php");
    exit();
}
$reqId = intval($_GET['id']);

// จัดการเมื่อมีการกดปุ่ม Approve/Reject
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $approverId = $_SESSION['user_id'];
    $newStatus = isset($_POST['approve']) ? 'Approved' : 'Rejected';
    
    updateRequisitionStatus($conn, $reqId, $approverId, $newStatus);
    
    header("Location: approve_requisitions.php");
    exit();
}

$details = getRequisitionDetailsById($conn, $reqId);
if (!$details['info']) {
    die("Requisition not found.");
}

$pageTitle = "รายละเอียดใบเบิก #" . str_pad($reqId, 6, "0", STR_PAD_LEFT);
require_once '../admin/partials/header.php';
?>

<div class="bg-white p-6 rounded-lg shadow-md max-w-4xl mx-auto">
    <div class="grid grid-cols-2 gap-4 mb-6">
        <div><strong>ผู้เบิก:</strong> <?php echo htmlspecialchars($details['info']['RequesterName']); ?></div>
        <div><strong>วันที่เบิก:</strong> <?php echo date("d/m/Y H:i", strtotime($details['info']['RequisitionDate'])); ?></div>
        <div><strong>สถานะ:</strong> <?php echo htmlspecialchars($details['info']['Status']); ?></div>
    </div>

    <h3 class="text-lg font-semibold mb-2">รายการที่เบิก</h3>
    <table class="min-w-full divide-y divide-gray-200 border">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-4 py-2 text-left">รายการ</th>
                <th class="px-4 py-2 text-right">จำนวน</th>
                <th class="px-4 py-2 text-left">หน่วย</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($details['items'] as $item): ?>
            <tr>
                <td class="px-4 py-2"><?php echo htmlspecialchars($item['ItemName']); ?></td>
                <td class="px-4 py-2 text-right"><?php echo number_format($item['QuantityRequested']); ?></td>
                <td class="px-4 py-2"><?php echo htmlspecialchars($item['Unit']); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php // แสดงปุ่มเฉพาะผู้มีสิทธิ์และใบเบิกยังเป็น Pending
    if (($details['info']['Status'] == 'Pending') && ($_SESSION['user_role'] == 'Admin' || $_SESSION['user_role'] == 'Approver')): ?>
    <form action="view_requisition.php?id=<?php echo $reqId; ?>" method="post" class="mt-6 border-t pt-4 flex justify-end gap-4">
        <button type="submit" name="reject" class="py-2 px-4 rounded-md text-white bg-red-600 hover:bg-red-700">ปฏิเสธ</button>
        <button type="submit" name="approve" class="py-2 px-4 rounded-md text-white bg-green-600 hover:bg-green-700">อนุมัติใบเบิก</button>
    </form>
    <?php endif; ?>
</div>

<?php
require_once '../admin/partials/footer.php';
?>
