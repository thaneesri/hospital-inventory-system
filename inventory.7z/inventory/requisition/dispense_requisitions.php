<?php
// File: requisition/dispense_requisitions.php

require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

if ($_SESSION['user_role'] != 'Admin' && $_SESSION['user_role'] != 'Dispenser') {
    die("Access Denied.");
}

$approvedResult = getApprovedRequisitions($conn);

$pageTitle = "รายการใบเบิกที่รอจ่าย";
require_once '../admin/partials/header.php';
?>

<div class="bg-white p-6 rounded-lg shadow-md">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left">เลขที่ใบเบิก</th>
                <th class="px-6 py-3 text-left">วันที่เบิก</th>
                <th class="px-6 py-3 text-left">ผู้เบิก</th>
                <th class="px-6 py-3 text-left">ผู้อนุมัติ</th>
                <th class="px-6 py-3 text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($approvedResult && $approvedResult->num_rows > 0) {
                while($row = $approvedResult->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td class='px-6 py-4'>#" . str_pad($row['RequisitionID'], 6, "0", STR_PAD_LEFT) . "</td>";
                    echo "<td class='px-6 py-4'>" . date("d/m/Y H:i", strtotime($row['RequisitionDate'])) . "</td>";
                    echo "<td class='px-6 py-4'>" . htmlspecialchars($row['RequesterName']) . "</td>";
                    echo "<td class='px-6 py-4'>" . htmlspecialchars($row['ApproverName']) . "</td>";
                    echo "<td class='px-6 py-4 text-right'>";
                    echo "<a href='view_requisition.php?id=" . $row['RequisitionID'] . "' class='text-indigo-600 hover:text-indigo-900'>ตรวจสอบ / จ่ายยา</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5' class='text-center p-4'>ไม่มีรายการรอจ่าย</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php
require_once '../admin/partials/footer.php';
?>
