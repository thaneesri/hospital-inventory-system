--
-- Database: `hospital_inventory`
--
CREATE DATABASE IF NOT EXISTS `hospital_inventory` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `hospital_inventory`;

-- --------------------------------------------------------

-- ----------------------------
-- Table structure for items
-- ----------------------------
DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `ItemID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemCode` varchar(50) DEFAULT NULL,
  `ItemName` varchar(255) NOT NULL,
  `ItemType` varchar(50) DEFAULT NULL,
  `Category` varchar(255) DEFAULT NULL,
  `Formulation` varchar(255) DEFAULT NULL COMMENT 'รูปแบบยา',
  `PackageSize` varchar(255) DEFAULT NULL COMMENT 'ขนาดบรรจุ',
  `Strength` text DEFAULT NULL COMMENT 'ความแรง',
  `Unit` varchar(50) NOT NULL COMMENT 'หน่วยนับ',
  `Price` decimal(10,2) DEFAULT 0.00,
  `ReorderPoint` int(11) DEFAULT 0,
  `AvgMonthlyUsage` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `IsActive` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`ItemID`),
  UNIQUE KEY `ItemCode` (`ItemCode`)
) ENGINE=InnoDB AUTO_INCREMENT=701 DEFAULT CHARSET=utf8mb4;


-- --------------------------------------------------------

--
-- Table structure for table `Users`
-- ตารางสำหรับเก็บข้อมูลผู้ใช้งาน
--

-- File: SQL Script to create Users table with default users

--
-- Table structure for table `Users`
--
CREATE TABLE `Users` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(255) NOT NULL,
  `Position` varchar(100) DEFAULT NULL,
  `UserRole` enum('Requester','Dispenser','Approver','Admin') NOT NULL,
  `Username` varchar(50) NOT NULL,
  `PasswordHash` varchar(255) NOT NULL,
  `MustChangePassword` tinyint(1) NOT NULL DEFAULT 1,
  `IsActive` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Users`
-- เพิ่มผู้ใช้เริ่มต้น 3 คน
--

-- 1. ผู้ดูแลระบบ (Admin) | รหัสผ่าน: password
INSERT INTO `Users` (`FullName`, `Position`, `UserRole`, `Username`, `PasswordHash`, `MustChangePassword`, `IsActive`) VALUES
('ผู้ดูแลระบบ', 'Admin', 'Admin', 'admin', '$2y$10$fW.1.a.pB3V5C5Z.f8j9c.L/d1D3eX2fG5h7kI9j8lK7m6n5o4pG', 1, 1);

-- 2. ผู้อำนวยการ รพ.สต. (Approver) | รหัสผ่าน: password123
INSERT INTO `Users` (`FullName`, `Position`, `UserRole`, `Username`, `PasswordHash`, `MustChangePassword`, `IsActive`) VALUES
('ผู้อำนวยการ รพ.สต.', 'ผู้อำนวยการ', 'Approver', 'director', '$2y$10$iAIfqUyapiPla38kpHeM7OOFjePTYvxfcWH7RrKkrTX6MLlkumuDe', 1, 1);

-- 3. เจ้าหน้าที่คลังยา (Dispenser) | รหัสผ่าน: password123
INSERT INTO `Users` (`FullName`, `Position`, `UserRole`, `Username`, `PasswordHash`, `MustChangePassword`, `IsActive`) VALUES
('เจ้าหน้าที่คลังยา', 'เภสัชกร', 'Dispenser', 'officer', '$2y$10$iAIfqUyapiPla38kpHeM7OOFjePTYvxfcWH7RrKkrTX6MLlkumuDe', 1, 1);



-- --------------------------------------------------------

--
-- Table structure for table `Stock`
-- ตารางสำหรับเก็บสต็อกสินค้าจริง แยกตาม Lot และวันหมดอายุ
--

CREATE TABLE `Stock` (
  `StockID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `LotNumber` varchar(100) NOT NULL,
  `ExpiryDate` date DEFAULT NULL,
  `Quantity` int(11) NOT NULL,
  `ReceivedDate` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`StockID`),
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Stock`
--
ALTER TABLE `Stock`
  ADD CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`ItemID`) REFERENCES `Items` (`ItemID`);

--
-- Table structure for table `Requisitions`
-- ตารางหลักสำหรับเก็บข้อมูลใบเบิก
--
CREATE TABLE `Requisitions` (
  `RequisitionID` int(11) NOT NULL AUTO_INCREMENT,
  `RequisitionDate` datetime NOT NULL DEFAULT current_timestamp(),
  `RequesterID` int(11) NOT NULL,
  `Status` enum('Pending','Approved','Rejected','Dispensed') NOT NULL DEFAULT 'Pending',
  `ApproverID` int(11) DEFAULT NULL,
  `ApprovalDate` datetime DEFAULT NULL,
  `DispenserID` int(11) DEFAULT NULL,
  `DispenseDate` datetime DEFAULT NULL,
  PRIMARY KEY (`RequisitionID`),
  KEY `RequesterID` (`RequesterID`),
  CONSTRAINT `requisitions_ibfk_1` FOREIGN KEY (`RequesterID`) REFERENCES `Users` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Table structure for table `Requisition_Items`
-- ตารางสำหรับเก็บรายการสินค้าในแต่ละใบเบิก
--
CREATE TABLE `Requisition_Items` (
  `RequisitionItemID` int(11) NOT NULL AUTO_INCREMENT,
  `RequisitionID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `QuantityRequested` int(11) NOT NULL,
  PRIMARY KEY (`RequisitionItemID`),
  KEY `RequisitionID` (`RequisitionID`),
  KEY `ItemID` (`ItemID`),
  CONSTRAINT `req_items_ibfk_1` FOREIGN KEY (`RequisitionID`) REFERENCES `Requisitions` (`RequisitionID`),
  CONSTRAINT `req_items_ibfk_2` FOREIGN KEY (`ItemID`) REFERENCES `Items` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 2. สร้างตารางสำหรับเก็บข้อมูลแผนการจัดซื้อ
CREATE TABLE `ProcurementPlans` (
  `PlanID` int(11) NOT NULL AUTO_INCREMENT,
  `PlanDate` date NOT NULL,
  `PlanName` varchar(255) NOT NULL,
  `Status` enum('Draft','Finalized','Ordered') NOT NULL DEFAULT 'Draft',
  `CreatedBy` int(11) NOT NULL,
  `CreatedAt` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`PlanID`),
  KEY `CreatedBy` (`CreatedBy`),
  CONSTRAINT `procurementplans_ibfk_1` FOREIGN KEY (`CreatedBy`) REFERENCES `Users` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. สร้างตารางสำหรับเก็บรายการยาในแต่ละแผน
CREATE TABLE `ProcurementPlanItems` (
  `PlanItemID` int(11) NOT NULL AUTO_INCREMENT,
  `PlanID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `CurrentStock` int(11) NOT NULL,
  `AvgMonthlyUsage` decimal(10,2) NOT NULL,
  `SuggestedQuantity` int(11) NOT NULL,
  `ActualQuantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`PlanItemID`),
  KEY `PlanID` (`PlanID`),
  KEY `ItemID` (`ItemID`),
  CONSTRAINT `planitems_ibfk_1` FOREIGN KEY (`PlanID`) REFERENCES `ProcurementPlans` (`PlanID`),
  CONSTRAINT `planitems_ibfk_2` FOREIGN KEY (`ItemID`) REFERENCES `Items` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 1. เพิ่มคอลัมน์ "ราคาซื้อจริง" ในตาราง Stock
ALTER TABLE `Stock`
ADD `PurchasePrice` DECIMAL(10,2) NULL DEFAULT NULL 
COMMENT 'ราคาซื้อจริงต่อหน่วยใหญ่' 
AFTER `Quantity`;

-- 2. เพิ่มคอลัมน์ "ราคาเฉลี่ยต่อหน่วยย่อย" ในตาราง Items
ALTER TABLE `Items`
ADD `AvgSubUnitPrice` DECIMAL(10,4) NOT NULL DEFAULT 0.0000 
COMMENT 'ราคาเฉลี่ยต่อหน่วยย่อย' 
AFTER `Price`;


-- ขั้นตอนที่ 2: เพิ่มคอลัมน์ Barcode เข้าไปในตาราง Stock (ตารางที่เก็บ Lot)
ALTER TABLE `Stock`
ADD `Barcode` VARCHAR(255) NULL DEFAULT NULL 
COMMENT 'บาร์โค้ดของล็อตสินค้านี้' 
AFTER `LotNumber`;

-- เพิ่มคอลัมน์ StockID เพื่ออ้างอิงไปยังล็อตสินค้าที่ต้องการเบิกโดยตรง
ALTER TABLE `Requisition_Items` 
ADD `StockID` INT(11) NOT NULL 
AFTER `ItemID`;
