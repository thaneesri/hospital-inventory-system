<?php
// File: /includes/db_connect.php

// --- Database Connection Configuration ---
// ตั้งค่าการเชื่อมต่อฐานข้อมูล
$servername = "localhost";      // Server name, usually "localhost" or "127.0.0.1"
$username = "sa";             // Default username for AppServ/XAMPP
$password = "sa";                 // Default password for AppServ/XAMPP is empty
$dbname = "hospital_inventory"; // The database name you created

// --- Create and Check Connection ---
// สร้างการเชื่อมต่อด้วย MySQLi
$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบว่าการเชื่อมต่อสำเร็จหรือไม่
if ($conn->connect_error) {
    // หากล้มเหลว ให้หยุดการทำงานและแสดงข้อความผิดพลาด
    die("Connection failed: " . $conn->connect_error);
}

// --- Set Character Set to UTF-8 ---
// ตั้งค่า Character Set ของการเชื่อมต่อเป็น utf8 เพื่อรองรับภาษาไทย
if (!$conn->set_charset("utf8")) {
    // หากตั้งค่าล้มเหลว ให้แสดงข้อความผิดพลาด (แต่ไม่หยุดการทำงาน)
    printf("Error loading character set utf8: %s\n", $conn->error);
}

// ไม่ต้องปิดการเชื่อมต่อ ($conn->close()) ในไฟล์นี้
// เพราะไฟล์อื่นๆ ที่เรียกใช้จะยังต้องการใช้งาน connection อยู่
// การเชื่อมต่อจะถูกปิดโดยอัตโนมัติเมื่อสคริปต์ทำงานเสร็จสิ้น
?>
