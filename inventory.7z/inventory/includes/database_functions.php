<?php
// File: /includes/database_functions.php

// เรียกใช้ไฟล์เชื่อมต่อฐานข้อมูลก่อนเสมอ
require_once 'db_connect.php';

// =================================================================
// Item Functions
// =================================================================

/**
 * ดึงข้อมูลยาและเวชภัณฑ์ทั้งหมดจากฐานข้อมูล (เวอร์ชันเต็ม)
 * @param object $conn Connection object
 * @return object|false The result object on success, or false on failure.
 */
function getAllItems($conn) {
    $sql = "SELECT 
                ItemID, ItemCode, ItemName, ItemType, Category, 
                Formulation, PackageSize, Strength, Unit, Price, ReorderPoint 
            FROM items 
            WHERE IsActive = TRUE 
            ORDER BY ItemType,Category,ItemName ASC";
    $result = $conn->query($sql);
    return $result;
}


/**
 * ดึงข้อมูลยา/เวชภัณฑ์ 1 รายการจาก ID (เวอร์ชันเต็ม)
 */
function getItemById($conn, $itemId) {
    // เลือกทุกคอลัมน์ที่ต้องการ
    $stmt = $conn->prepare("SELECT ItemID, ItemCode, ItemName, ItemType, Category, Formulation, PackageSize, Strength, Unit, Price, ReorderPoint FROM items WHERE ItemID = ?");
    if ($stmt === false) return null;
    
    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $result = $stmt->get_result();
    $item = $result->fetch_assoc();
    $stmt->close();
    return $item;
}


/**
 * เพิ่มข้อมูลยา/เวชภัณฑ์ใหม่ (เพิ่ม Formulation และ PackageSize)
 */
function insertItem($conn, $itemData) {
    $stmt = $conn->prepare("INSERT INTO items (ItemCode, ItemName, ItemType, Formulation, PackageSize, Unit, Price, ReorderPoint) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) return "Error preparing statement: " . $conn->error;
    
    $stmt->bind_param("ssssssdi",
        $itemData['itemCode'], $itemData['itemName'], $itemData['itemType'],
        $itemData['formulation'], $itemData['packageSize'], $itemData['unit'], 
        $itemData['price'], $itemData['reorderPoint']
    );

    if ($stmt->execute()) { $stmt->close(); return true; } 
    else { $error = $stmt->error; $stmt->close(); return $error; }
}

/**
 * อัปเดตข้อมูลยา/เวชภัณฑ์ (เวอร์ชันเต็ม)
 * หมายเหตุ: ไม่มีการอัปเดต ItemCode เพราะเป็นคีย์หลัก
 */
function updateItem($conn, $itemData) {
    $sql = "UPDATE items SET 
                ItemName = ?, ItemType = ?, Category = ?, Formulation = ?, 
                PackageSize = ?, Strength = ?, Unit = ?, Price = ?, ReorderPoint = ? 
            WHERE ItemID = ?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        return "Error preparing statement: " . $conn->error;
    }

    $stmt->bind_param("ssssssdii",
        $itemData['itemName'], $itemData['itemType'], $itemData['category'],
        $itemData['formulation'], $itemData['packageSize'], $itemData['strength'],
        $itemData['unit'], $itemData['price'], $itemData['reorderPoint'],
        $itemData['itemId']
    );

    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        $error = $stmt->error;
        $stmt->close();
        return $error;
    }
}


/**
 * ลบข้อมูลยา/เวชภัณฑ์ (Soft Delete) โดยการตั้งค่า IsActive = FALSE
 * @param object $conn Connection object
 * @param int $itemId ID ของรายการที่ต้องการลบ
 * @return bool|string Returns true on success, or an error message string on failure.
 */
function deleteItemById($conn, $itemId) {
    $stmt = $conn->prepare("UPDATE items SET IsActive = FALSE WHERE ItemID = ?");
    if ($stmt === false) {
        return "Error preparing statement: " . $conn->error;
    }
    
    $stmt->bind_param("i", $itemId);

    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        $error_message = $stmt->error;
        $stmt->close();
        return $error_message;
    }
}


// =================================================================
// User Functions
// =================================================================

/**
 * ดึงข้อมูลผู้ใช้งานทั้งหมดจากฐานข้อมูล
 * @param object $conn Connection object
 * @return object|false The result object on success, or false on failure.
 */
function getAllUsers($conn) {
    $sql = "SELECT UserID, FullName, Position, UserRole, Username FROM users WHERE IsActive = TRUE ORDER BY UserID DESC";
    $result = $conn->query($sql);
    return $result;
}

/**
 * เพิ่มข้อมูลผู้ใช้ใหม่ลงในฐานข้อมูลอย่างปลอดภัย พร้อมเข้ารหัสรหัสผ่าน
 * @param object $conn Connection object
 * @param array $userData ข้อมูลผู้ใช้ในรูปแบบ associative array
 * @return string|true Returns true on success, or an error message string on failure.
 */
function insertUser($conn, $userData) {
    $passwordHash = password_hash($userData['password'], PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (FullName, Position, UserRole, Username, PasswordHash) VALUES (?, ?, ?, ?, ?)");
    if ($stmt === false) {
        return "Error preparing statement: " . $conn->error;
    }
    $stmt->bind_param("sssss", $userData['fullName'], $userData['position'], $userData['userRole'], $userData['username'], $passwordHash);
    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        $error_message = $stmt->error;
        $stmt->close();
        return $error_message;
    }
}

/**
 * ดึงข้อมูลผู้ใช้ 1 คนจาก ID
 * @param object $conn Connection object
 * @param int $userId ID ของผู้ใช้
 * @return array|null Returns an associative array of the user data, or null if not found.
 */
function getUserById($conn, $userId) {
    $stmt = $conn->prepare("SELECT UserID, FullName, Position, UserRole, Username FROM users WHERE UserID = ?");
    if ($stmt === false) return null;
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    return $user;
}

/**
 * อัปเดตข้อมูลผู้ใช้
 * @param object $conn Connection object
 * @param array $userData ข้อมูลที่ต้องการอัปเดต
 * @return bool|string Returns true on success, or an error message string on failure.
 */
function updateUser($conn, $userData) {
    if (!empty($userData['password'])) {
        $passwordHash = password_hash($userData['password'], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET FullName = ?, Position = ?, UserRole = ?, Username = ?, PasswordHash = ? WHERE UserID = ?");
        $stmt->bind_param("sssssi", $userData['fullName'], $userData['position'], $userData['userRole'], $userData['username'], $passwordHash, $userData['userId']);
    } else {
        $stmt = $conn->prepare("UPDATE users SET FullName = ?, Position = ?, UserRole = ?, Username = ? WHERE UserID = ?");
        $stmt->bind_param("ssssi", $userData['fullName'], $userData['position'], $userData['userRole'], $userData['username'], $userData['userId']);
    }
    if ($stmt === false) return "Error preparing statement: " . $conn->error;
    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        $error_message = $stmt->error;
        $stmt->close();
        return $error_message;
    }
}

/**
 * ลบข้อมูลผู้ใช้ (Soft Delete)
 * @param object $conn Connection object
 * @param int $userId ID ของผู้ใช้
 * @return bool|string Returns true on success, or an error message string on failure.
 */
function deleteUserById($conn, $userId) {
    $stmt = $conn->prepare("UPDATE users SET IsActive = FALSE WHERE UserID = ?");
    if ($stmt === false) return "Error preparing statement: " . $conn->error;
    $stmt->bind_param("i", $userId);
    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        $error_message = $stmt->error;
        $stmt->close();
        return $error_message;
    }
}

/**
 * ตรวจสอบข้อมูลการ Login ของผู้ใช้
 * @param object $conn Connection object
 * @param string $username
 * @param string $password
 * @return array|false Returns user data array on success, or false on failure.
 */
function verifyUserLogin($conn, $username, $password) {
    // เพิ่ม MustChangePassword เข้าไปใน SELECT
    $stmt = $conn->prepare("SELECT UserID, FullName, UserRole, PasswordHash, MustChangePassword FROM users WHERE Username = ? AND IsActive = TRUE");
    if ($stmt === false) return false;

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['PasswordHash'])) {
            unset($user['PasswordHash']);
            $stmt->close();
            return $user; // คืนค่าข้อมูลผู้ใช้ทั้งหมด (รวม MustChangePassword)
        }
    }
    
    $stmt->close();
    return false;
}

// --- เพิ่มฟังก์ชันใหม่นี้เข้าไป ---
/**
 * อัปเดตรหัสผ่านใหม่และยกเลิกการบังคับเปลี่ยน
 */
function updatePasswordAndFlag($conn, $userId, $newPassword) {
    $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
    // อัปเดตทั้งรหัสผ่านและตั้งค่า MustChangePassword เป็น 0
    $stmt = $conn->prepare("UPDATE users SET PasswordHash = ?, MustChangePassword = 0 WHERE UserID = ?");
    if ($stmt === false) return "Prepare failed: " . $conn->error;

    $stmt->bind_param("si", $passwordHash, $userId);
    if ($stmt->execute()) {
        // อัปเดต session ด้วย
        $_SESSION['must_change_password'] = 0;
        $stmt->close();
        return true;
    } else {
        $error = $stmt->error;
        $stmt->close();
        return $error;
    }
}


// =================================================================
// Stock Functions
// =================================================================

/**
 * บันทึกการรับสินค้าเข้าสต็อก และคำนวณราคาเฉลี่ยใหม่ (Weighted Average)
 * @param object $conn Connection object
 * @param array $stockData ข้อมูลสต็อก
 * @return bool|string Returns true on success, or an error message string on failure.
   * สร้างใบเบิกใหม่ (เวอร์ชันอัปเกรด - บันทึกตาม StockID)
 */
function receiveStockItem($conn, $stockData) {
    // เริ่มต้น Transaction เพื่อให้แน่ใจว่าข้อมูลจะถูกบันทึกทั้งหมดหรือยกเลิกทั้งหมด
    $conn->begin_transaction();
    try {
        // --- ขั้นตอนที่ 1: เพิ่มข้อมูล Lot ใหม่ลงในตาราง Stock ---
		$stmt1 = $conn->prepare("INSERT INTO stock (ItemID, LotNumber, Barcode, ExpiryDate, Quantity, PurchasePrice) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt1 === false) throw new Exception("Prepare failed (Stock Insert): " . $conn->error);

		$barcode = !empty($stockData['barcode']) ? $stockData['barcode'] : null;
        $expiryDate = !empty($stockData['expiryDate']) ? $stockData['expiryDate'] : null;
        $purchasePrice = !empty($stockData['purchasePrice']) ? $stockData['purchasePrice'] : null;

		$stmt1->bind_param("issssd",
			$stockData['itemId'], $stockData['lotNumber'], $barcode, $expiryDate,
			$stockData['quantity'], $purchasePrice
		);
        $stmt1->execute();
        $stmt1->close();

        // --- ขั้นตอนที่ 2: คำนวณราคาเฉลี่ยต่อหน่วยย่อยใหม่ ---
        // ดึงข้อมูลสต็อกทั้งหมดของยานี้ (รวม Lot ใหม่ที่เพิ่งเพิ่มเข้าไป)
        $stmt2 = $conn->prepare("SELECT Quantity, PurchasePrice FROM stock WHERE ItemID = ? AND Quantity > 0 AND PurchasePrice IS NOT NULL");
        if ($stmt2 === false) throw new Exception("Prepare failed (Stock Select): " . $conn->error);
        
        $stmt2->bind_param("i", $stockData['itemId']);
        $stmt2->execute();
        $stockResult = $stmt2->get_result();

        $totalValue = 0;
        $totalQuantity = 0;

        while ($row = $stockResult->fetch_assoc()) {
            $totalValue += $row['Quantity'] * $row['PurchasePrice'];
            $totalQuantity += $row['Quantity'];
        }
        $stmt2->close();

        $newAvgSubUnitPrice = 0;
        if ($totalQuantity > 0 && $stockData['subUnits'] > 0) {
            // คำนวณราคาเฉลี่ยต่อหน่วยใหญ่
            $avgPricePerMainUnit = $totalValue / $totalQuantity;
            // คำนวณราคาเฉลี่ยต่อหน่วยย่อย
            $newAvgSubUnitPrice = $avgPricePerMainUnit / $stockData['subUnits'];
        }

        // --- ขั้นตอนที่ 3: อัปเดตราคาเฉลี่ยใหม่ลงในตาราง items ---
        $stmt3 = $conn->prepare("UPDATE items SET AvgSubUnitPrice = ? WHERE ItemID = ?");
        if ($stmt3 === false) throw new Exception("Prepare failed (Items Update): " . $conn->error);

        $stmt3->bind_param("di", $newAvgSubUnitPrice, $stockData['itemId']);
        $stmt3->execute();
        $stmt3->close();

        // ถ้าทุกอย่างสำเร็จ ให้ commit transaction
        $conn->commit();
        return true;

    } catch (Exception $e) {
        // ถ้าเกิดข้อผิดพลาด ให้ rollback transaction
        $conn->rollback();
        return $e->getMessage();
    }
}


/**
 * คำนวณยอดคงเหลือทั้งหมดของสินค้าแต่ละรายการ
 * @param object $conn Connection object
 * @return array Returns an associative array with ItemID as key and total quantity as value.
 */
function getTotalStockGroupedByItem($conn) {
    $sql = "SELECT ItemID, SUM(Quantity) as TotalStock FROM stock GROUP BY ItemID";
    $result = $conn->query($sql);
    $stockTotals = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $stockTotals[$row['ItemID']] = $row['TotalStock'];
        }
    }
    return $stockTotals;
}

/**
 * ดึงประวัติความเคลื่อนไหวของสินค้า (Stock Card)
 * @param object $conn Connection object
 * @param int $itemId ID ของสินค้า
 * @return object|false The result object on success, or false on failure.
 */
function getItemStockHistory($conn, $itemId) {
    $stmt = $conn->prepare("SELECT ReceivedDate, LotNumber, ExpiryDate, Quantity FROM stock WHERE ItemID = ? ORDER BY ReceivedDate DESC");
    if ($stmt === false) return false;
    
    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    return $stmt->get_result();
}

// =================================================================
// Requisition Functions
// =================================================================

/**
 * สร้างใบเบิกใหม่ (ใช้ Transaction)
 * @param object $conn Connection object
 * @param int $requesterId ID ของผู้เบิก
 * @param array $itemsArray อาร์เรย์ของรายการที่เบิก
 * @return bool|string Returns true on success, or an error message string on failure.
   * สร้างใบเบิกใหม่ (เวอร์ชันอัปเกรด - บันทึกตาม StockID)
 */
function createRequisition($conn, $requesterId, $itemsArray) {
    $conn->begin_transaction();
    try {
        $stmt1 = $conn->prepare("INSERT INTO requisitions (RequesterID) VALUES (?)");
        if ($stmt1 === false) throw new Exception("Prepare failed (Requisitions): " . $conn->error);
        
        $stmt1->bind_param("i", $requesterId);
        $stmt1->execute();
        $requisitionId = $conn->insert_id;
        $stmt1->close();

        // แก้ไข statement ให้รับ ItemID และ StockID
        $stmt2 = $conn->prepare("INSERT INTO requisition_items (RequisitionID, ItemID, StockID, QuantityRequested) VALUES (?, ?, ?, ?)");
        if ($stmt2 === false) throw new Exception("Prepare failed (Requisition_Items): " . $conn->error);

        foreach ($itemsArray as $item) {
            // bind parameter 4 ตัว
            $stmt2->bind_param("iiii", $requisitionId, $item['itemId'], $item['stockId'], $item['quantity']);
            $stmt2->execute();
        }
        $stmt2->close();

        $conn->commit();
        return true;

    } catch (Exception $e) {
        $conn->rollback();
        return $e->getMessage();
    }
}

/**
 * ดึงข้อมูลใบเบิกทั้งหมดของผู้ใช้คนนั้นๆ
 * @param object $conn Connection object
 * @param int $userId ID ของผู้ใช้
 * @return object|false The result object on success, or false on failure.
 */
function getRequisitionsByUserId($conn, $userId) {
    $stmt = $conn->prepare(
        "SELECT r.RequisitionID, r.RequisitionDate, r.Status, u.FullName as ApproverName
         FROM requisitions r
         LEFT JOIN users u ON r.ApproverID = u.UserID
         WHERE r.RequesterID = ?
         ORDER BY r.RequisitionDate DESC"
    );
    if ($stmt === false) return false;

    $stmt->bind_param("i", $userId);
    $stmt->execute();
    return $stmt->get_result();
}

/**
 * ดึงข้อมูลใบเบิกที่รออนุมัติ (Pending) ทั้งหมด
 */
function getPendingRequisitions($conn) {
    $sql = "SELECT r.RequisitionID, r.RequisitionDate, u.FullName as RequesterName
            FROM requisitions r
            JOIN users u ON r.RequesterID = u.UserID
            WHERE r.Status = 'Pending'
            ORDER BY r.RequisitionDate ASC";
    return $conn->query($sql);
}

/**
 * ดึงข้อมูลรายละเอียดทั้งหมดของใบเบิก 1 ใบ
 */
function getRequisitionDetailsById($conn, $requisitionId) {
    $details = ['info' => null, 'items' => []];

    // Get main info
    $stmt1 = $conn->prepare("SELECT r.*, u.FullName as RequesterName FROM requisitions r JOIN users u ON r.RequesterID = u.UserID WHERE r.RequisitionID = ?");
    $stmt1->bind_param("i", $requisitionId);
    $stmt1->execute();
    $result1 = $stmt1->get_result();
    $details['info'] = $result1->fetch_assoc();
    $stmt1->close();

    // Get items
    $stmt2 = $conn->prepare("SELECT ri.*, i.ItemName, i.Unit FROM requisition_items ri JOIN items i ON ri.ItemID = i.ItemID WHERE ri.RequisitionID = ?");
    $stmt2->bind_param("i", $requisitionId);
    $stmt2->execute();
    $result2 = $stmt2->get_result();
    while ($row = $result2->fetch_assoc()) {
        $details['items'][] = $row;
    }
    $stmt2->close();

    return $details;
}

/**
 * อัปเดตสถานะของใบเบิก (Approve/Reject)
 */
function updateRequisitionStatus($conn, $requisitionId, $approverId, $newStatus) {
    $stmt = $conn->prepare("UPDATE requisitions SET Status = ?, ApproverID = ?, ApprovalDate = NOW() WHERE RequisitionID = ? AND Status = 'Pending'");
    if ($stmt === false) return "Prepare failed: " . $conn->error;
    
    $stmt->bind_param("sii", $newStatus, $approverId, $requisitionId);
    
    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        $error = $stmt->error;
        $stmt->close();
        return $error;
    }
}

/**
 * ดึงข้อมูลใบเบิกที่อนุมัติแล้ว (Approved) ทั้งหมด
 */
function getApprovedRequisitions($conn) {
    $sql = "SELECT r.RequisitionID, r.RequisitionDate, u_req.FullName as RequesterName, u_app.FullName as ApproverName
            FROM requisitions r
            JOIN users u_req ON r.RequesterID = u_req.UserID
            LEFT JOIN users u_app ON r.ApproverID = u_app.UserID
            WHERE r.Status = 'Approved'
            ORDER BY r.RequisitionDate ASC";
    return $conn->query($sql);
}

/**
 * ทำการจ่ายยาและตัดสต็อก (ใช้ Transaction)
 */
function dispenseRequisition($conn, $requisitionId, $dispenserId) {
    $conn->begin_transaction();
    try {
        // 1. ดึงรายการยาที่ต้องจ่าย
        $details = getRequisitionDetailsById($conn, $requisitionId);
        if (!$details['info'] || $details['info']['Status'] !== 'Approved') {
            throw new Exception("ใบเบิกไม่อยู่ในสถานะที่สามารถจ่ายได้");
        }

        foreach ($details['items'] as $item) {
            $itemId = $item['ItemID'];
            $quantityToDispense = $item['QuantityRequested'];

            // 2. ตรวจสอบสต็อกคงเหลือทั้งหมด
            $stockCheckStmt = $conn->prepare("SELECT SUM(Quantity) as Total FROM stock WHERE ItemID = ?");
            $stockCheckStmt->bind_param("i", $itemId);
            $stockCheckStmt->execute();
            $stockResult = $stockCheckStmt->get_result()->fetch_assoc();
            if ($stockResult['Total'] < $quantityToDispense) {
                throw new Exception("สต็อกไม่เพียงพอสำหรับรายการ: " . $item['ItemName']);
            }
            $stockCheckStmt->close();

            // 3. ดึง Lot ที่มีของและเก่าที่สุดก่อน (FIFO)
            $fifoStmt = $conn->prepare("SELECT StockID, Quantity FROM stock WHERE ItemID = ? AND Quantity > 0 ORDER BY ReceivedDate ASC");
            $fifoStmt->bind_param("i", $itemId);
            $fifoStmt->execute();
            $lots = $fifoStmt->get_result();
            $fifoStmt->close();

            // 4. วนลูปตัดสตอกจากแต่ละ Lot
            while ($lot = $lots->fetch_assoc()) {
                if ($quantityToDispense <= 0) break;

                $stockId = $lot['StockID'];
                $lotQuantity = $lot['Quantity'];
                
                $deductAmount = min($quantityToDispense, $lotQuantity);

                $updateStmt = $conn->prepare("UPDATE stock SET Quantity = Quantity - ? WHERE StockID = ?");
                $updateStmt->bind_param("ii", $deductAmount, $stockId);
                $updateStmt->execute();
                $updateStmt->close();

                $quantityToDispense -= $deductAmount;
            }
        }

        // 5. อัปเดตสถานะใบเบิกเป็น Dispensed
        $updateReqStmt = $conn->prepare("UPDATE requisitions SET Status = 'Dispensed', DispenserID = ?, DispenseDate = NOW() WHERE RequisitionID = ?");
        $updateReqStmt->bind_param("ii", $dispenserId, $requisitionId);
        $updateReqStmt->execute();
        $updateReqStmt->close();

        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        return $e->getMessage();
    }
}

/**
 * ดึงข้อมูลรายงานสรุปการเบิกจ่ายตามเงื่อนไข
 * @param object $conn Connection object
 * @param string $startDate วันที่เริ่มต้นในรูปแบบ 'YYYY-MM-DD'
 * @param string $endDate วันที่สิ้นสุดในรูปแบบ 'YYYY-MM-DD'
 * @param string $status สถานะที่ต้องการ (เช่น 'All', 'Pending', 'Approved')
 * @return object|false The result object on success, or false on failure.
 */
function getRequisitionReport($conn, $startDate, $endDate, $status) {
    // เพิ่มเวลาสิ้นสุดของวัน (23:59:59) เพื่อให้ครอบคลุมข้อมูลทั้งหมดของวันนั้นๆ
    $endDate = $endDate . ' 23:59:59';

    // เตรียม SQL หลัก
    $sql = "SELECT 
                r.RequisitionID, 
                r.RequisitionDate, 
                r.Status,
                u_req.FullName as RequesterName,
                -- ส่วนนี้คือ Subquery สำหรับคำนวณมูลค่ารวมของแต่ละใบเบิก
                (SELECT SUM(ri.QuantityRequested * i.Price) 
                 FROM requisition_items ri 
                 JOIN items i ON ri.ItemID = i.ItemID 
                 WHERE ri.RequisitionID = r.RequisitionID) as TotalValue
            FROM requisitions r
            JOIN users u_req ON r.RequesterID = u_req.UserID
            WHERE r.RequisitionDate BETWEEN ? AND ?";

    // เพิ่มเงื่อนไขตามสถานะ ถ้าไม่ได้เลือก 'All'
    if ($status != 'All') {
        $sql .= " AND r.Status = ?";
        $stmt = $conn->prepare($sql);
        // "sss" หมายถึงตัวแปร 3 ตัวเป็น string (startDate, endDate, status)
        $stmt->bind_param("sss", $startDate, $endDate, $status);
    } else {
        $stmt = $conn->prepare($sql);
        // "ss" หมายถึงตัวแปร 2 ตัวเป็น string (startDate, endDate)
        $stmt->bind_param("ss", $startDate, $endDate);
    }
    
    $stmt->execute();
    return $stmt->get_result();
}

/**
 * ดึงข้อมูลรายงานมูลค่าคงคลัง
 * @param object $conn Connection object
 * @return object|false The result object on success, or false on failure.
 */
function getInventoryValueReport($conn) {
    // เตรียม SQL query
    $sql = "SELECT 
                i.ItemCode,
                i.ItemName,
                i.Unit,
                i.Price,
                -- คำนวณยอดรวมของสินค้าแต่ละชนิดจากตาราง Stock
                SUM(s.Quantity) as CurrentStock,
                -- คำนวณมูลค่ารวมของสินค้าแต่ละชนิด
                (SUM(s.Quantity) * i.Price) as TotalValue
            FROM items i
            -- เชื่อมตาราง Items กับ Stock ด้วย ItemID
            JOIN stock s ON i.ItemID = s.ItemID
            -- กรองเอาเฉพาะสินค้าที่ยังใช้งานอยู่ (IsActive = TRUE) และมีของในสต็อก (Quantity > 0)
            WHERE i.IsActive = TRUE AND s.Quantity > 0
            -- จัดกลุ่มข้อมูลตามรายการสินค้า
            GROUP BY i.ItemID, i.ItemCode, i.ItemName, i.Unit, i.Price
            -- เรียงลำดับตามชื่อสินค้า
            ORDER BY i.ItemName ASC";
    
    // รัน query และคืนค่าผลลัพธ์
    return $conn->query($sql);
}

/**
 * นับจำนวนรายการยาและเวชภัณฑ์ทั้งหมด (รองรับการค้นหา)
 * @param object $conn Connection object
 * @param string $searchTerm คำที่ใช้ค้นหา
 * @return int จำนวนรายการทั้งหมดที่พบ
 */
function countAllItems($conn, $searchTerm = '') {
    $sql = "SELECT COUNT(ItemID) as total FROM items WHERE IsActive = TRUE";
    $params = [];
    $types = '';

    // ถ้ามีคำค้นหา ให้เพิ่มเงื่อนไข WHERE
    if (!empty($searchTerm)) {
        $sql .= " AND (ItemName LIKE ? OR ItemCode LIKE ?)";
        $likeTerm = "%" . $searchTerm . "%";
        $params[] = $likeTerm;
        $params[] = $likeTerm;
        $types .= 'ss';
    }

    $stmt = $conn->prepare($sql);
    if (!empty($searchTerm)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $result['total'];
}

/**
 * ดึงข้อมูลยาและเวชภัณฑ์แบบแบ่งหน้า (รองรับการค้นหา)
 * @param object $conn Connection object
 * @param int $limit จำนวนรายการต่อหน้า
 * @param int $offset ตำแหน่งที่เริ่มดึงข้อมูล
 * @param string $searchTerm คำที่ใช้ค้นหา
 * @return object|false The result object on success, or false on failure.
 */
function getItemsPaginated($conn, $limit, $offset, $searchTerm = '') {
    $sql = "SELECT *
            FROM items
            WHERE IsActive = TRUE";
    $params = [];
    $types = '';

    // ถ้ามีคำค้นหา ให้เพิ่มเงื่อนไข WHERE
    if (!empty($searchTerm)) {
        $sql .= " AND (ItemName LIKE ? OR ItemCode LIKE ?)";
        $likeTerm = "%" . $searchTerm . "%";
        $params[] = $likeTerm;
        $params[] = $likeTerm;
        $types .= 'ss';
    }

    // เพิ่ม ORDER BY, LIMIT, และ OFFSET สำหรับการแบ่งหน้า
    $sql .= " ORDER BY Category,ItemName ASC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $types .= 'ii';

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    return $stmt->get_result();
}


/**
 * นำเข้ารายการยาและเวชภัณฑ์จากไฟล์ CSV ไปยังฐานข้อมูล
 * (เวอร์ชันปรับปรุงเพื่อดีบักและค้นหาสาเหตุของข้อผิดพลาด)
 *
 * @param mysqli $conn Object การเชื่อมต่อฐานข้อมูล mysqli
 * @param string $filePath ตำแหน่งของไฟล์ CSV
 * @return array ผลลัพธ์การทำงาน ประกอบด้วย 'success', 'skipped', และ 'errors' (พร้อมรายละเอียด)
 */
function importItemsFromCSV($conn, $filePath) {
    // ตั้งค่าการเชื่อมต่อฐานข้อมูลให้รองรับภาษาไทย (UTF-8)
    // *** สำคัญมาก: ควรใส่โค้ดส่วนนี้หลังจากการเชื่อมต่อฐานข้อมูลเสมอ ***
    $conn->set_charset("utf8");

    $result = ['success' => 0, 'skipped' => 0, 'errors' => []]; // เปลี่ยน errors เป็น array

    if (($handle = fopen($filePath, "r")) === FALSE) {
        $result['errors'][] = ['data' => 'N/A', 'message' => 'ไม่สามารถเปิดไฟล์ได้: ' . $filePath];
        return $result;
    }

    $conn->begin_transaction();

    try {
        $checkStmt = $conn->prepare("SELECT ItemID FROM items WHERE ItemCode = ?");
        $insertStmt = $conn->prepare(
            "INSERT INTO items (ItemCode, ItemName, ItemType, Category, Formulation, PackageSize, Strength, Unit, Price, ReorderPoint)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        // ข้ามแถวแรก (Header)
        fgetcsv($handle);

        $rowNumber = 1; // ตัวแปรนับแถวสำหรับอ้างอิง
        while (($data = fgetcsv($handle)) !== FALSE) {
            $rowNumber++;

            // ตรวจสอบว่ามีข้อมูลอย่างน้อย 10 คอลัมน์หรือไม่ เพื่อป้องกัน lỗi "Undefined offset"
            if (count($data) < 10) {
                 $result['errors'][] = ['row' => $rowNumber, 'data' => implode(',', $data), 'message' => 'จำนวนคอลัมน์ไม่ครบ'];
                 continue;
            }

            if (empty(trim($data[0]))) {
                continue; // ข้ามแถวที่ไม่มี ItemCode
            }

            $itemCode     = trim($data[0]);
            $itemName     = trim($data[1]);
            $itemType     = trim($data[2]);
            $category     = trim($data[3]);
            // สำหรับคอลัมน์ที่อาจเป็นค่าว่าง ให้ส่ง NULL แทนสตริงว่าง ''
            $formulation  = !empty(trim($data[4])) ? trim($data[4]) : null;
            $packageSize  = !empty(trim($data[5])) ? trim($data[5]) : null;
            $strength     = !empty(trim($data[6])) ? trim($data[6]) : null;
            $unit         = trim($data[7]);
            $price        = !empty(trim($data[8])) ? floatval(trim($data[8])) : 0.0;
            $reorderPoint = !empty(trim($data[9])) ? intval(trim($data[9])) : 0;

            // ตรวจสอบข้อมูลซ้ำ
            $checkStmt->bind_param("s", $itemCode);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();

            if ($checkResult->num_rows > 0) {
                $result['skipped']++;
            } else {
                // bind_param ไม่สามารถรับตัวแปร null ได้โดยตรง ต้องใช้ bind_param ร่วมกับ call_user_func_array
                // แต่เพื่อความง่าย จะใช้การส่งค่า null ไปตรงๆ ซึ่งอาจต้องปรับโค้ดส่วนเชื่อมต่อ PDO ในอนาคต
                // ใน mysqli การส่ง null ใน bind_param จะถูกแปลงเป็นสตริงว่าง ซึ่งอาจทำให้เกิดปัญหาเดิม
                // อย่างไรก็ตาม การเก็บ error message จะช่วยให้เห็นปัญหาชัดเจนขึ้น
                $insertStmt->bind_param(
                    "ssssssssdi",
                    $itemCode, $itemName, $itemType, $category,
                    $formulation, $packageSize, $strength, $unit,
                    $price, $reorderPoint
                );

                if ($insertStmt->execute()) {
                    $result['success']++;
                } else {
                    // *** ส่วนที่สำคัญที่สุด: เก็บข้อความ Error ที่เกิดขึ้น ***
                    $result['errors'][] = [
                        'row' => $rowNumber,
                        'item_code' => $itemCode,
                        'message' => $insertStmt->error // ดึงข้อความ Error จาก MySQL
                    ];
                }
            }
        }

        // หากมี error เกิดขึ้น ให้ rollback transaction
        if (!empty($result['errors'])) {
            $conn->rollback();
        } else {
            $conn->commit();
        }

    } catch (Exception $e) {
        $conn->rollback();
        $result['errors'][] = ['data' => 'Transaction Failed', 'message' => $e->getMessage()];
    } finally {
        if (isset($checkStmt)) $checkStmt->close();
        if (isset($insertStmt)) $insertStmt->close();
        fclose($handle);
    }

    return $result;
}



/**
 * ดึงข้อมูลสินค้าที่ใกล้หมด (ยอดคงเหลือ < จุดสั่งซื้อ)
 * @param object $conn Connection object
 * @return object|false The result object on success, or false on failure.
 */
function getLowStockItems($conn) {
    $sql = "SELECT i.ItemID, i.ItemName, i.Unit, i.ReorderPoint, SUM(s.Quantity) as CurrentStock
            FROM items i
            LEFT JOIN stock s ON i.ItemID = s.ItemID
            WHERE i.IsActive = TRUE
            GROUP BY i.ItemID, i.ItemName, i.Unit, i.ReorderPoint
            HAVING CurrentStock < i.ReorderPoint AND i.ReorderPoint > 0";
    return $conn->query($sql);
}

/**
 * ดึงข้อมูลสินค้าที่ใกล้หมดอายุ (เช่น ภายใน 90 วัน)
 * @param object $conn Connection object
 * @param int $days จำนวนวันที่ต้องการแจ้งเตือนล่วงหน้า
 * @return object|false The result object on success, or false on failure.
 */
function getNearExpiryItems($conn, $days = 90) {
    $sql = "SELECT i.ItemName, s.LotNumber, s.ExpiryDate, s.Quantity
            FROM stock s
            JOIN items i ON s.ItemID = i.ItemID
            WHERE s.ExpiryDate BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
            AND s.Quantity > 0
            ORDER BY s.ExpiryDate ASC";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) return false;

    $stmt->bind_param("i", $days);
    $stmt->execute();
    return $stmt->get_result();
}

// =================================================================
// Procurement Functions
// =================================================================

/**
 * คำนวณและบันทึกอัตราการใช้เฉลี่ยต่อเดือนของยาทุกรายการ (ย้อนหลัง 3 เดือน)
 */
function calculateAndStoreAverageUsage($conn) {
    // รีเซ็ตค่าเก่าทั้งหมดเป็น 0 ก่อนคำนวณใหม่
    $conn->query("UPDATE items SET AvgMonthlyUsage = 0");

    // ดึงยอดรวมที่จ่ายออกไปใน 3 เดือนล่าสุด
    $sql = "SELECT
                ri.ItemID,
                SUM(ri.QuantityRequested) as TotalDispensed
            FROM requisition_items ri
            JOIN requisitions r ON ri.RequisitionID = r.RequisitionID
            WHERE
                r.Status = 'Dispensed' AND
                r.DispenseDate >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
            GROUP BY ri.ItemID";

    $result = $conn->query($sql);
    if ($result) {
        $updateStmt = $conn->prepare("UPDATE items SET AvgMonthlyUsage = ? WHERE ItemID = ?");
        while ($row = $result->fetch_assoc()) {
            $avgUsage = $row['TotalDispensed'] / 3; // หาร 3 เพื่อหาค่าเฉลี่ยต่อเดือน
            $updateStmt->bind_param("di", $avgUsage, $row['ItemID']);
            $updateStmt->execute();
        }
        $updateStmt->close();
        return true;
    }
    return false;
}

/**
 * สร้างแผนการจัดซื้อฉบับร่างขึ้นมาใหม่
 */
function generateProcurementPlan($conn, $planName, $userId) {
    $conn->begin_transaction();
    try {
        // 1. สร้างแผนใหม่ในตาราง ProcurementPlans
        $planStmt = $conn->prepare("INSERT INTO procurement_plans (PlanDate, PlanName, CreatedBy) VALUES (CURDATE(), ?, ?)");
        $planStmt->bind_param("si", $planName, $userId);
        $planStmt->execute();
        $planId = $conn->insert_id;
        $planStmt->close();

        // 2. ดึงข้อมูลยา, ยอดคงเหลือ, และอัตราการใช้
        $itemsSql = "SELECT
                        i.ItemID, i.AvgMonthlyUsage,
                        COALESCE(SUM(s.Quantity), 0) as CurrentStock
                    FROM items i
                    LEFT JOIN stock s ON i.ItemID = s.ItemID
                    WHERE i.IsActive = TRUE
                    GROUP BY i.ItemID, i.AvgMonthlyUsage";

        $itemsResult = $conn->query($itemsSql);
        $itemPlanStmt = $conn->prepare("INSERT INTO procurement_plan_items (PlanID, ItemID, CurrentStock, AvgMonthlyUsage, SuggestedQuantity) VALUES (?, ?, ?, ?, ?)");

        while ($item = $itemsResult->fetch_assoc()) {
            // 3. คำนวณยอดที่ควรสั่ง (ให้มีของพอใช้ 3 เดือน - ยอดคงเหลือ)
            $targetStock = $item['AvgMonthlyUsage'] * 3;
            $suggestedQty = ceil($targetStock - $item['CurrentStock']);
            
            // ถ้าคำนวณแล้วติดลบ ให้เป็น 0
            if ($suggestedQty < 0) {
                $suggestedQty = 0;
            }

            // เพิ่มลงในแผนเฉพาะรายการที่ต้องสั่งซื้อ (ยอดแนะนำ > 0)
            if ($suggestedQty > 0) {
                $itemPlanStmt->bind_param("iiidi", $planId, $item['ItemID'], $item['CurrentStock'], $item['AvgMonthlyUsage'], $suggestedQty);
                $itemPlanStmt->execute();
            }
        }
        $itemPlanStmt->close();

        $conn->commit();
        return $planId; // คืนค่า ID ของแผนที่สร้างใหม่
    } catch (Exception $e) {
        $conn->rollback();
        return "Error: " . $e->getMessage();
    }
}

/**
 * ดึงประวัติแผนการจัดซื้อทั้งหมด
 */
function getAllProcurementPlans($conn) {
    $sql = "SELECT p.PlanID, p.PlanDate, p.PlanName, p.Status, u.FullName as CreatorName
            FROM procurement_plans p
            JOIN users u ON p.CreatedBy = u.UserID
            ORDER BY p.PlanDate DESC";
    return $conn->query($sql);
}

/**
 * ดึงรายละเอียดทั้งหมดของแผนการจัดซื้อ 1 แผน
 */
function getProcurementPlanDetails($conn, $planId) {
    $sql = "SELECT 
                pi.PlanItemID, pi.CurrentStock, pi.AvgMonthlyUsage, 
                pi.SuggestedQuantity, pi.ActualQuantity,
                i.ItemName, i.Unit
            FROM procurement_plan_items pi
            JOIN items i ON pi.ItemID = i.ItemID
            WHERE pi.PlanID = ?
            ORDER BY i.ItemName ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $planId);
    $stmt->execute();
    return $stmt->get_result();
}

/**
 * บันทึกการแก้ไขยอดสั่งซื้อจริงในแผน
 */
function updateProcurementPlanItems($conn, $planId, $actualQuantities) {
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE procurement_plan_items SET ActualQuantity = ? WHERE PlanItemID = ? AND PlanID = ?");
        foreach ($actualQuantities as $planItemId => $quantity) {
            // ถ้าผู้ใช้ไม่กรอก ให้ถือว่าเป็น 0
            $qtyToUpdate = !empty($quantity) ? intval($quantity) : 0;
            $stmt->bind_param("iii", $qtyToUpdate, $planItemId, $planId);
            $stmt->execute();
        }
        $stmt->close();
        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        return "Error: " . $e->getMessage();
    }
}

/**
 * ดึงข้อมูลรายงานสินค้าคงคลัง (แยกตาม Lot)
 */
function getInventoryOnHandReport($conn) {
    $sql = "SELECT
                i.ItemCode,
                i.ItemName,
                i.Unit,
                s.LotNumber,
                s.ExpiryDate,
                s.Quantity
            FROM stock s
            JOIN items i ON s.ItemID = i.ItemID
            WHERE s.Quantity > 0 AND i.IsActive = TRUE
            ORDER BY i.ItemName ASC, s.ExpiryDate ASC";
    return $conn->query($sql);
}

/**
 * ดึงข้อมูลรายงานสินค้าด้วย Barcode 
 */
function getItemByBarcode($conn, $barcode) {
    // ค้นหาในตาราง Stock แล้ว JOIN ไปหาชื่อในตาราง Items
    $sql = "SELECT 
                i.ItemID, 
                i.ItemName
            FROM stock s
            JOIN items i ON s.ItemID = i.ItemID
            WHERE s.Barcode = ? 
            LIMIT 1"; // เอาแค่รายการเดียว

    $stmt = $conn->prepare($sql);
    if ($stmt === false) return null;
    
    $stmt->bind_param("s", $barcode);
    $stmt->execute();
    $result = $stmt->get_result();
    $item = $result->fetch_assoc();
    $stmt->close();
    return $item;
}


/**
 * ดึงข้อมูลสต็อก Lot ทั้งหมดที่มีของ (Quantity > 0)
 */
function getActiveStockLots($conn) {
    $sql = "SELECT
                s.StockID,
                s.LotNumber,
                s.ExpiryDate,
                s.Quantity,
                i.ItemID,
                i.ItemName,
                i.Unit
            FROM stock s
            JOIN items i ON s.ItemID = i.ItemID
            WHERE s.Quantity > 0 AND i.IsActive = TRUE
            ORDER BY i.ItemName ASC, s.ExpiryDate ASC";
    return $conn->query($sql);
}

// =================================================================
// Import/Export Functions
// =================================================================


/**
 * อ่านและตรวจสอบข้อมูลจากไฟล์ CSV ใบส่งของ (ยังไม่บันทึก)
 * @return array ข้อมูลที่อ่านได้พร้อมสถานะการตรวจสอบ
 */
function parseDeliveryNoteCSV($conn, $filePath) {
    $parsedData = [];
    
    if (($handle = fopen($filePath, "r")) !== FALSE) {
        fgetcsv($handle, 1000, ","); // ข้ามแถวแรก (หัวตาราง)

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            if (count($data) < 6) continue; // ข้ามแถวที่ข้อมูลไม่ครบ

            $itemCode = trim($data[0]);
            $itemId = getItemIdByCode($conn, $itemCode);

            $parsedRow = [
                'itemCode'      => $itemCode,
                'itemId'        => $itemId, // จะเป็น null ถ้าไม่พบ
                'lotNumber'     => trim($data[1]),
                'expiryDate'    => trim($data[2]),
                'quantity'      => intval(trim($data[3])),
                'purchasePrice' => floatval(trim($data[4])),
                'subUnits'      => intval(trim($data[5])),
                'barcode'       => isset($data[6]) ? trim($data[6]) : null,
                'status'        => $itemId ? 'found' : 'not_found' // สถานะการตรวจสอบ
            ];
            $parsedData[] = $parsedRow;
        }
        fclose($handle);
    }
    return $parsedData;
}
?>
