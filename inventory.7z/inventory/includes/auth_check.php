
<?php
// File: /includes/auth_check.php (โค้ดทั้งหมด)

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// ถ้ายังไม่ login ให้กลับไปหน้า login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// ถ้าถูกบังคับให้เปลี่ยนรหัสผ่าน และยังไม่ได้อยู่ที่หน้าเปลี่ยนรหัสผ่าน
// ให้ส่งไปที่หน้าเปลี่ยนรหัสผ่านทันที
if ($_SESSION['must_change_password'] == 1 && basename($_SERVER['PHP_SELF']) != 'force_change_password.php') {
    // ตรวจสอบ path สำหรับ logout
    $logoutPath = (basename($_SERVER['PHP_SELF']) == 'logout.php') ? '' : '../';
    header("Location: {$logoutPath}force_change_password.php");
    exit();
}
?>
