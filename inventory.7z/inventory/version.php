<?php
// File: /version.php

// กำหนดเวอร์ชันปัจจุบันของโปรแกรม
define('CURRENT_VERSION', '1.0.0');

?>