<?php
// File: /login.php

// เริ่มต้น session
session_start();
//echo '<div style="position:absolute;top:0px;">' . password_hash('password', PASSWORD_DEFAULT) . '</div>';
// ถ้า login อยู่แล้ว ให้ redirect ไปหน้า dashboard

if (isset($_SESSION['user_id']) && $_SESSION['must_change_password'] != 1) {
    header("Location: index.php");
    exit();
}

require_once 'includes/database_functions.php';

$errorMessage = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $user = verifyUserLogin($conn, $username, $password);

    if ($user) {
        // Login สำเร็จ, เก็บข้อมูลผู้ใช้ลงใน session
        $_SESSION['user_id'] = $user['UserID'];
        $_SESSION['full_name'] = $user['FullName'];
        $_SESSION['user_role'] = $user['UserRole'];
        $_SESSION['must_change_password'] = $user['MustChangePassword'];

        // ตรวจสอบว่าต้องเปลี่ยนรหัสผ่านหรือไม่
        if ($_SESSION['must_change_password'] == 1) {
            header("Location: force_change_password.php");
        } else {
            header("Location: index.php");
        }
        exit();
    } else {
        // Login ไม่สำเร็จ
        $errorMessage = "Username หรือ Password ไม่ถูกต้อง!";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ระบบคลังยา รพ.สต.</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', sans-serif; }
    </style>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">

    <div class="w-full max-w-md bg-white rounded-lg shadow-md p-8">
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-6">ระบบคลังยาและเวชภัณฑ์</h2>
        
        <?php if ($errorMessage): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" role="alert">
                <?php echo $errorMessage; ?>
            </div>
        <?php endif; ?>

        <form action="login.php" method="post">
            <div class="mb-4">
                <label for="username" class="block text-gray-700 text-sm font-bold mb-2">Username</label>
                <input type="text" name="username" id="username" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
            </div>
            <div class="mb-6">
                <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password</label>
                <!-- ส่วนแสดง/ซ่อนรหัสผ่าน -->
                <div class="relative">
                    <input type="password" name="password" id="password" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline pr-10" required>
                    <button type="button" id="togglePassword" class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-500 hover:text-gray-700">
                        <svg id="eye-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        <svg id="eye-off-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye-off hidden"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>
                    </button>
                </div>
            </div>
            <div class="flex items-center justify-between">
                <button type="submit" name="login" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full">
                    เข้าสู่ระบบ
                </button>
            </div>
        </form>
    </div>

    <script>
        // JavaScript สำหรับปุ่มแสดง/ซ่อนรหัสผ่าน
        const togglePasswordBtn = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        const eyeIcon = document.getElementById('eye-icon');
        const eyeOffIcon = document.getElementById('eye-off-icon');

        togglePasswordBtn.addEventListener('click', function() {
            // สลับประเภทของ input
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';

            // สลับไอคอน
            eyeIcon.classList.toggle('hidden', isPassword);
            eyeOffIcon.classList.toggle('hidden', !isPassword);
        });
    </script>

</body>
</html>
