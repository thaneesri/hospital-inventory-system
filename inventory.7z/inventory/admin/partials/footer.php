<?php
// File: /admin/partials/footer.php
?>
    </div> <!-- ปิด container ของ Main Content Area จาก header.php -->

</body>
</html>
