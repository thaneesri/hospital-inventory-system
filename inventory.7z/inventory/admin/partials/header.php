<?php 
// File: /admin/partials/header.php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$current_script = $_SERVER['SCRIPT_NAME'];

function get_nav_link_class($directory_or_file) {
    global $current_script;
    $base_classes = "px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200";
    $active_classes = "bg-indigo-700 text-white";
    $inactive_classes = "text-gray-200 hover:bg-gray-700 hover:text-white";

    if (strpos($current_script, $directory_or_file) !== false) {
        return "$base_classes $active_classes";
    }
    return "$base_classes $inactive_classes";
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) : "ระบบคลังยา รพ.สต."; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Sarabun', sans-serif; }
    </style>
</head>
<body class="bg-gray-100">
    <nav class="bg-gray-800">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0 text-white font-bold text-lg">
                        รพ.สต. คลังยา
                    </div>
                    <div class="hidden md:block">
                        <div class="ml-10 flex items-baseline space-x-2">
                            <a href="/inventory/index.php" class="<?php echo get_nav_link_class('index.php'); ?>">Dashboard</a>
                            
                            <?php if (isset($_SESSION['user_id'])): ?>
                                <a href="/inventory/requisition/my_requisitions.php" class="<?php echo get_nav_link_class('requisition'); ?>">เบิกจ่าย</a>
                                <a href="/inventory/stock/procurement_plan.php" class="<?php echo get_nav_link_class('stock'); ?>">คลังสินค้า</a>
                                <a href="/inventory/reports/summary_report.php" class="<?php echo get_nav_link_class('reports'); ?>">รายงาน</a>
                                <a href="/inventory/admin/items.php" class="<?php echo get_nav_link_class('admin'); ?>">ตั้งค่าระบบ</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="hidden md:block">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <div class="ml-4 flex items-center md:ml-6">
                            <span class="text-gray-300 text-sm mr-3">
                                สวัสดี, <?php echo htmlspecialchars($_SESSION['full_name']); ?>
                            </span>
                            <a href="/inventory/logout.php" class="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-md text-sm font-medium">ออกจากระบบ</a>
                        </div>
                    <?php else: ?>
                        <div class="ml-4 flex items-center md:ml-6">
                            <a href="/inventory/login.php" class="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded-md text-sm font-medium">เข้าสู่ระบบ</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
    <div class="container mx-auto p-4 sm:p-6 lg:p-8">
        <div class="flex justify-between items-center">
            <h1 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-6"><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) : "Dashboard"; ?></h1>
            
            <?php // --- เมนูย่อยสำหรับหน้า "คลังสินค้า" ---
            if (isset($_SESSION['user_id']) && strpos($_SERVER['PHP_SELF'], 'stock')) { ?>
            <div class="mb-6 flex items-center gap-2">
                <a href="procurement_plan.php" class="text-sm font-medium px-4 py-2 rounded-md <?php echo (basename($_SERVER['PHP_SELF']) == 'procurement_plan.php') ? 'bg-indigo-100 text-indigo-700' : 'text-gray-600 hover:bg-gray-100'; ?>">วางแผนจัดซื้อ</a>
                <a href="receive_stock.php" class="text-sm font-medium px-4 py-2 rounded-md <?php echo (basename($_SERVER['PHP_SELF']) == 'receive_stock.php') ? 'bg-indigo-100 text-indigo-700' : 'text-gray-600 hover:bg-gray-100'; ?>">รับของเข้าคลัง</a>
            </div>
            <?php } ?>

            <?php // --- เมนูย่อยสำหรับหน้า "รายงาน" ---
            if (isset($_SESSION['user_id']) && strpos($_SERVER['PHP_SELF'], 'reports')) { ?>
            <div class="mb-6 flex items-center gap-2">
                <a href="summary_report.php" class="text-sm font-medium px-4 py-2 rounded-md <?php echo (basename($_SERVER['PHP_SELF']) == 'summary_report.php') ? 'bg-indigo-100 text-indigo-700' : 'text-gray-600 hover:bg-gray-100'; ?>">รายงานการเบิกจ่าย</a>
                <a href="inventory_value_report.php" class="text-sm font-medium px-4 py-2 rounded-md <?php echo (basename($_SERVER['PHP_SELF']) == 'inventory_value_report.php') ? 'bg-indigo-100 text-indigo-700' : 'text-gray-600 hover:bg-gray-100'; ?>">รายงานมูลค่าคงคลัง</a>
                <a href="inventory_on_hand_report.php" class="text-sm font-medium px-4 py-2 rounded-md <?php echo (basename($_SERVER['PHP_SELF']) == 'inventory_on_hand_report.php') ? 'bg-indigo-100 text-indigo-700' : 'text-gray-600 hover:bg-gray-100'; ?>">รายงานสินค้าคงคลัง</a>
            </div>
            <?php } ?>
        </div>
<!-- ในไฟล์ admin/partials/header.php -->
<?php // Sub-menu for Admin page
if (isset($_SESSION['user_id']) && strpos($_SERVER['PHP_SELF'], 'admin')) { ?>
<div class="mb-6 flex items-center gap-2">
    <a href="items.php" class="...">จัดการยา</a>
    <a href="users.php" class="...">จัดการผู้ใช้</a>
    <!-- เพิ่มลิงก์นี้เข้าไป -->
    <a href="updater.php" class="text-sm font-medium px-4 py-2 rounded-md <?php echo (basename($_SERVER['PHP_SELF']) == 'updater.php') ? 'bg-indigo-100 text-indigo-700' : 'text-gray-600 hover:bg-gray-100'; ?>">ระบบอัปเดต</a>
</div>
<?php } ?>