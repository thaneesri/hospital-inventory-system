<?php
// File: /admin/export_items.php (เวอร์ชันสำหรับ .xlsx)

// *** เพิ่มเข้ามา: เริ่มการทำ Output Buffering ***
// เพื่อดักจับข้อมูลที่ไม่ต้องการ (เช่น whitespace, errors) ไม่ให้ไปปนกับไฟล์ Excel
ob_start();

// 1. เรียกใช้ Autoloader ของ Composer เพื่อให้ PHP รู้จักไลบรารี PhpSpreadsheet
// ใช้ __DIR__ เพื่อให้แน่ใจว่า path ถูกต้องเสมอ ไม่ว่าจะเรียกใช้ไฟล์นี้จากที่ไหน
require_once __DIR__ . '/../vendor/autoload.php';

// เรียกใช้ไฟล์เชื่อมต่อฐานข้อมูล
require_once __DIR__ . '/../includes/database_functions.php';

// 2. เรียกใช้งานคลาสที่จำเป็นจาก PhpSpreadsheet
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;

// 3. สร้างอ็อบเจ็กต์ Spreadsheet ใหม่
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('รายการยาและเวชภัณฑ์'); // ตั้งชื่อชีต

// 4. กำหนดส่วนหัวของตาราง (Header) และจัดรูปแบบ
$header = [
    'ItemCode'      => 'รหัสสินค้า',
    'ItemName'      => 'ชื่อรายการ',
    'ItemType'      => 'ประเภท',
    'Category'      => 'หมวดหมู่',
    'Formulation'   => 'รูปแบบยา',
    'PackageSize'   => 'ขนาดบรรจุ',
    'Strength'      => 'ความแรง',
    'Unit'          => 'หน่วยนับ',
    'Price'         => 'ราคา/หน่วย',
    'ReorderPoint'  => 'จุดสั่งซื้อ'
];

// เขียน Header ลงในแถวแรก โดยใช้ key-value pair เพื่อให้อ่านง่าย
$sheet->fromArray(array_values($header), NULL, 'A1');

// จัดสไตล์ให้ Header (ตัวหนา, สีขาว, พื้นหลังสีน้ำเงินเข้ม, จัดกลาง)
$headerStyle = [
    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '4F46E5']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER]
];
$sheet->getStyle('A1:J1')->applyFromArray($headerStyle);


// 5. ดึงข้อมูลจากฐานข้อมูล
try {
    // ตั้งค่าการเชื่อมต่อให้เป็น UTF-8 เพื่อความมั่นใจ
    $conn->set_charset("utf8");

    $sql = "SELECT 
                ItemCode, ItemName, ItemType, Category, Formulation, 
                PackageSize, Strength, Unit, Price, ReorderPoint 
            FROM Items 
            ORDER BY ItemName ASC";

    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        // เขียนข้อมูลลงในชีต เริ่มจากแถวที่ 2
        $rowIndex = 2;
        while ($row = $result->fetch_assoc()) {
            // เรียงข้อมูลในแถวให้ตรงกับลำดับของ Header
            $rowData = [];
            foreach (array_keys($header) as $dbKey) {
                $rowData[] = $row[$dbKey];
            }
            $sheet->fromArray($rowData, NULL, 'A' . $rowIndex);
            $rowIndex++;
        }
    }

    // 6. ปรับความกว้างของคอลัมน์อัตโนมัติเพื่อให้พอดีกับข้อมูล
    foreach (range('A', 'J') as $columnID) {
        $sheet->getColumnDimension($columnID)->setAutoSize(true);
    }

} catch (Exception $e) {
    // หากเกิดข้อผิดพลาด ให้เขียน Error ลงในชีตแทน
    $sheet->setCellValue('A2', 'เกิดข้อผิดพลาดระหว่างการดึงข้อมูล: ' . $e->getMessage());
}

// *** เพิ่มเข้ามา: ล้าง Buffer ทั้งหมดก่อนส่ง Header ***
ob_end_clean();

// 7. ตั้งค่า HTTP Headers เพื่อส่งไฟล์ Excel ให้เบราว์เซอร์
$filename = "ItemsExport_" . date('Y-m-d') . ".xlsx";
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . urlencode($filename) . '"');
header('Cache-Control: max-age=0');
header('Pragma: public'); // สำหรับ IE

// 8. สร้าง Writer และส่งไฟล์ไปยัง Output ของ PHP
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');

// 9. ปิดการเชื่อมต่อและจบการทำงานของสคริปต์
if ($conn) {
    $conn->close();
}
exit();

?>
