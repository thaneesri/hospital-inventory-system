<?php
// File: /admin/edit_item.php

require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

$message = "";
$item = null;

if (!isset($_GET['id'])) {
    header("Location: items.php");
    exit();
}
$itemId = intval($_GET['id']);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_item'])) {
    $itemData = [
        'itemId'        => $itemId,
        'itemName'      => $_POST['itemName'],
        'itemType'      => $_POST['itemType'], // รับค่าจาก Radio Button
        'category'      => $_POST['category'],
        'formulation'   => $_POST['formulation'],
        'packageSize'   => $_POST['packageSize'],
        'strength'      => $_POST['strength'],
        'unit'          => $_POST['unit'],
        'price'         => $_POST['price'],
        'reorderPoint'  => $_POST['reorderPoint']
    ];
    $result = updateItem($conn, $itemData);
    if ($result === true) {
        header("Location: items.php?status=updatesuccess");
        exit();
    } else {
        $message = "<div class='bg-red-100 p-3 rounded'>เกิดข้อผิดพลาด: " . htmlspecialchars($result) . "</div>";
    }
}

$item = getItemById($conn, $itemId);
if (!$item) {
    header("Location: items.php");
    exit();
}

$pageTitle = "แก้ไขข้อมูล: " . htmlspecialchars($item['ItemName']);
require_once 'partials/header.php';
?>

<!-- ฟอร์มแก้ไขข้อมูล (ใช้ Radio Button) -->
<div class="bg-white p-6 rounded-lg shadow-md">
    <?php echo $message; ?>
    <form action="edit_item.php?id=<?php echo $itemId; ?>" method="post" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div>
            <label class="block text-sm font-medium text-gray-700">รหัสสินค้า (คีย์หลัก)</label>
            <input type="text" value="<?php echo htmlspecialchars($item['ItemCode']); ?>" class="mt-1 block w-full bg-gray-100 border-gray-300 rounded-md" readonly>
        </div>
        <div>
            <label for="itemName" class="block text-sm font-medium text-gray-700">ชื่อรายการ</label>
            <input type="text" name="itemName" id="itemName" value="<?php echo htmlspecialchars($item['ItemName']); ?>" class="mt-1 block w-full border-gray-300 rounded-md" required>
        </div>
        <div>
            <label for="category" class="block text-sm font-medium text-gray-700">กลุ่มยา/หมวดหมู่</label>
            <input type="text" name="category" id="category" value="<?php echo htmlspecialchars($item['Category']); ?>" class="mt-1 block w-full border-gray-300 rounded-md">
        </div>
        
        <!-- --- ส่วนของ Radio Button --- -->
        <div>
            <label class="block text-sm font-medium text-gray-700">ประเภท</label>
            <div class="mt-2 flex space-x-4">
                <div class="flex items-center">
                    <input id="type_drug" name="itemType" type="radio" value="drug" <?php if($item['ItemType'] == 'drug') echo 'checked'; ?> class="h-4 w-4 text-indigo-600 border-gray-300">
                    <label for="type_drug" class="ml-2 block text-sm text-gray-900">ยา </label>
                </div>
                <div class="flex items-center">
                    <input id="type_nondrug" name="itemType" type="radio" value="non-drug" <?php if($item['ItemType'] == 'non-drug') echo 'checked'; ?> class="h-4 w-4 text-indigo-600 border-gray-300">
                    <label for="type_nondrug" class="ml-2 block text-sm text-gray-900">เวชภัณฑ์ </label>
                </div>
            </div>
        </div>

        <div>
            <label for="formulation" class="block text-sm font-medium text-gray-700">รูปแบบยา</label>
            <input type="text" name="formulation" id="formulation" value="<?php echo htmlspecialchars($item['Formulation']); ?>" class="mt-1 block w-full border-gray-300 rounded-md">
        </div>
        <div>
            <label for="packageSize" class="block text-sm font-medium text-gray-700">ขนาดบรรจุ</label>
            <input type="text" name="packageSize" id="packageSize" value="<?php echo htmlspecialchars($item['PackageSize']); ?>" class="mt-1 block w-full border-gray-300 rounded-md">
        </div>
        <div>
            <label for="strength" class="block text-sm font-medium text-gray-700">ความแรง</label>
            <input type="text" name="strength" id="strength" value="<?php echo htmlspecialchars($item['Strength']); ?>" class="mt-1 block w-full border-gray-300 rounded-md">
        </div>
        <div>
            <label for="unit" class="block text-sm font-medium text-gray-700">หน่วยนับ</label>
            <input type="text" name="unit" id="unit" value="<?php echo htmlspecialchars($item['Unit']); ?>" class="mt-1 block w-full border-gray-300 rounded-md" required>
        </div>
        <div>
            <label for="price" class="block text-sm font-medium text-gray-700">ราคา/หน่วย</label>
            <input type="number" step="0.01" name="price" id="price" value="<?php echo htmlspecialchars($item['Price']); ?>" class="mt-1 block w-full border-gray-300 rounded-md">
        </div>
        <div>
            <label for="reorderPoint" class="block text-sm font-medium text-gray-700">จุดสั่งซื้อ</label>
            <input type="number" name="reorderPoint" id="reorderPoint" value="<?php echo htmlspecialchars($item['ReorderPoint']); ?>" class="mt-1 block w-full border-gray-300 rounded-md">
        </div>

        <div class="lg:col-span-4 mt-4">
            <button type="submit" name="update_item" class="w-auto py-2 px-4 rounded-md text-white bg-indigo-600 hover:bg-indigo-700">บันทึกการแก้ไข</button>
            <a href="items.php" class="ml-4 w-auto py-2 px-4 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50">ยกเลิก</a>
        </div>
    </form>
</div>

<?php
require_once 'partials/footer.php';
?>
