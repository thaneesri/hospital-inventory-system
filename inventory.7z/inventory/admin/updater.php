<?php
// File: /admin/updater.php

require_once '../includes/auth_check.php';
// จำกัดสิทธิ์เฉพาะ Admin เท่านั้น
if ($_SESSION['user_role'] != 'Admin') {
    die("Access Denied.");
}
require_once '../version.php'; // เรียกใช้ไฟล์เวอร์ชัน

// --- ตั้งค่า GitHub Repository ของคุณ ---
$githubUser = 'thaneesri'; // <<-- แก้ไขเป็น Username ของคุณ
$githubRepo = 'hospital-inventory-system'; // <<-- แก้ไขเป็นชื่อ Repository ของคุณ

$latestVersion = 'Error';
$updateAvailable = false;

// --- ติดต่อ GitHub API เพื่อดึงเวอร์ชันล่าสุด ---
$opts = ['http' => ['header' => 'User-Agent: PHP']];
$context = stream_context_create($opts);
$versionUrl = "https://raw.githubusercontent.com/{$githubUser}/{$githubRepo}/main/version.txt";
$remoteVersionContent = @file_get_contents($versionUrl, false, $context);

if ($remoteVersionContent) {
    $latestVersion = trim($remoteVersionContent);
    // เปรียบเทียบเวอร์ชัน
    if (version_compare($latestVersion, CURRENT_VERSION, '>')) {
        $updateAvailable = true;
    }
}

$pageTitle = "ระบบอัปเดตโปรแกรม";
require_once 'partials/header.php';
?>

<div class="bg-white p-6 rounded-lg shadow-md max-w-2xl mx-auto">
    <h2 class="text-xl font-semibold mb-4">สถานะเวอร์ชัน</h2>
    <div class="grid grid-cols-2 gap-4">
        <div class="text-center border p-4 rounded-lg">
            <h3 class="text-sm font-medium text-gray-500">เวอร์ชันปัจจุบัน</h3>
            <p class="text-2xl font-bold"><?php echo CURRENT_VERSION; ?></p>
        </div>
        <div class="text-center border p-4 rounded-lg">
            <h3 class="text-sm font-medium text-gray-500">เวอร์ชันล่าสุด</h3>
            <p class="text-2xl font-bold <?php echo $updateAvailable ? 'text-green-600' : ''; ?>">
                <?php echo htmlspecialchars($latestVersion); ?>
            </p>
        </div>
    </div>

    <div class="mt-6 text-center">
        <?php if ($updateAvailable): ?>
            <div class="bg-green-100 p-4 rounded-md mb-4">
                <p class="font-bold text-green-800">มีเวอร์ชันใหม่ (<?php echo htmlspecialchars($latestVersion); ?>) พร้อมให้อัปเดต!</p>
            </div>
            <form action="run_update.php" method="post">
                <button type="submit" name="start_update" class="w-full py-3 px-6 rounded-md text-white bg-indigo-600 hover:bg-indigo-700 font-bold" onclick="return confirm('คำเตือน: การอัปเดตจะเขียนทับไฟล์โปรแกรมทั้งหมด โปรดสำรองข้อมูลก่อนดำเนินการเสมอ! คุณต้องการดำเนินการต่อหรือไม่?');">
                    เริ่มการอัปเดต
                </button>
            </form>
        <?php else: ?>
            <div class="bg-blue-100 p-4 rounded-md">
                <p class="font-bold text-blue-800">คุณกำลังใช้งานเวอร์ชันล่าสุดอยู่</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
require_once 'partials/footer.php';
?>
