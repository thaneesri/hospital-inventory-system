<?php
// File: /admin/import_items.php

// 1. เรียกใช้ไฟล์ที่จำเป็น
require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';
// เรียกใช้ Autoloader ของ Composer เพื่อให้รู้จัก PhpSpreadsheet
require_once '../vendor/autoload.php';

// เรียกใช้คลาสที่จำเป็น
use PhpOffice\PhpSpreadsheet\IOFactory;

// ตัวแปรสำหรับเก็บข้อความผลลัพธ์
$message = "";
$resultSummary = ['success' => 0, 'skipped' => 0, 'errors' => 0, 'error_details' => []];

// 2. ตรวจสอบเมื่อมีการส่งฟอร์ม (อัปโหลดไฟล์)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["importFile"])) {

    // ตรวจสอบว่ามีไฟล์อัปโหลดมาหรือไม่ และไม่มี error
    if ($_FILES["importFile"]["error"] == UPLOAD_ERR_OK) {
        $filePath = $_FILES["importFile"]["tmp_name"];
        
        try {
            // 3. ใช้ IOFactory เพื่อโหลดไฟล์อัตโนมัติ (ทั้ง .xlsx และ .csv)
            $spreadsheet = IOFactory::load($filePath);
            $worksheet = $spreadsheet->getActiveSheet();
            // แปลงข้อมูลทั้งหมดในชีตเป็น array
            $data = $worksheet->toArray();

            // ตรวจสอบว่ามีข้อมูลหรือไม่
            if (count($data) > 1) {
                // ข้ามแถวแรก (Header)
                $isFirstRow = true;

                // เริ่ม Transaction
                $conn->begin_transaction();

                // เตรียมคำสั่ง SQL
                $checkStmt = $conn->prepare("SELECT ItemID FROM Items WHERE ItemCode = ?");
                $insertStmt = $conn->prepare(
                    "INSERT INTO Items (ItemCode, ItemName, ItemType, Category, Formulation, PackageSize, Strength, Unit, Price, ReorderPoint)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );

                foreach ($data as $row) {
                    if ($isFirstRow) {
                        $isFirstRow = false;
                        continue;
                    }

                    // ตรวจสอบว่า ItemCode ไม่ใช่ค่าว่าง
                    if (empty(trim($row[0]))) {
                        continue;
                    }
                    
                    // 4. จับคู่ข้อมูลจาก Array ไปยังตัวแปร
                    $itemCode     = trim($row[0]);
                    $itemName     = trim($row[1]);
                    $itemType     = trim($row[2]);
                    $category     = trim($row[3]);
                    $formulation  = trim($row[4]);
                    $packageSize  = trim($row[5]);
                    $strength     = trim($row[6]);
                    $unit         = trim($row[7]);
                    $price        = !empty(trim($row[8])) ? floatval(trim($row[8])) : 0.0;
                    $reorderPoint = !empty(trim($row[9])) ? intval(trim($row[9])) : 0;

                    // ตรวจสอบข้อมูลซ้ำ
                    $checkStmt->bind_param("s", $itemCode);
                    $checkStmt->execute();
                    $checkResult = $checkStmt->get_result();

                    if ($checkResult->num_rows > 0) {
                        $resultSummary['skipped']++;
                    } else {
                        // เพิ่มข้อมูลใหม่
                        $insertStmt->bind_param(
                            "ssssssssdi",
                            $itemCode, $itemName, $itemType, $category,
                            $formulation, $packageSize, $strength, $unit,
                            $price, $reorderPoint
                        );

                        if ($insertStmt->execute()) {
                            $resultSummary['success']++;
                        } else {
                            $resultSummary['errors']++;
                            $resultSummary['error_details'][] = "ItemCode " . htmlspecialchars($itemCode) . ": " . $insertStmt->error;
                        }
                    }
                }

                // ปิด Prepared Statements
                $checkStmt->close();
                $insertStmt->close();

                // ยืนยัน Transaction
                $conn->commit();

                // สร้างข้อความสรุปผล
                $message = "<div class='bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-4' role='alert'>";
                $message .= "<strong>การนำเข้าเสร็จสมบูรณ์!</strong><br>";
                $message .= "- เพิ่มข้อมูลสำเร็จ: " . $resultSummary['success'] . " รายการ<br>";
                $message .= "- ข้อมูลซ้ำ (ข้าม): " . $resultSummary['skipped'] . " รายการ<br>";
                $message .= "- พบข้อผิดพลาด: " . $resultSummary['errors'] . " รายการ";
                if ($resultSummary['errors'] > 0) {
                    $message .= "<br><br><strong>รายละเอียดข้อผิดพลาด:</strong><br>" . implode('<br>', $resultSummary['error_details']);
                }
                $message .= "</div>";


            } else {
                $message = "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4' role='alert'>ไฟล์ที่อัปโหลดไม่มีข้อมูล</div>";
            }
        } catch (Exception $e) {
            if ($conn->ping()) {
                $conn->rollback(); // ยกเลิก Transaction หากเกิดข้อผิดพลาด
            }
            $message = "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4' role='alert'>เกิดข้อผิดพลาดในการประมวลผลไฟล์: " . $e->getMessage() . "</div>";
        }
    } else {
        $message = "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4' role='alert'>เกิดข้อผิดพลาดในการอัปโหลดไฟล์</div>";
    }
}

// 5. เรียกใช้ Header
$pageTitle = "นำเข้าข้อมูลจากไฟล์";
require_once 'partials/header.php';
?>

<!-- ส่วนของ UI สำหรับอัปโหลดไฟล์ -->
<div class="bg-white p-6 rounded-lg shadow-md mb-8">
    <h2 class="text-xl font-semibold text-gray-700 mb-4">นำเข้าข้อมูลยาและเวชภัณฑ์</h2>
    
    <?php echo $message; // แสดงผลลัพธ์การนำเข้า ?>

    <div class="bg-gray-50 p-4 rounded-md border border-gray-200 mb-6">
        <h3 class="text-lg font-medium text-gray-800 mb-2">คำแนะนำ</h3>
        <ul class="list-disc list-inside text-gray-600 space-y-1">
            <li>รองรับไฟล์ประเภท Excel (.xlsx) และ CSV (.csv)</li>
            <li>ไฟล์ต้องมี 10 คอลัมน์เรียงตามลำดับดังนี้: <br>
                <code class="text-sm bg-gray-200 p-1 rounded">ItemCode, ItemName, ItemType, Category, Formulation, PackageSize, Strength, Unit, Price, ReorderPoint</code>
            </li>
            <li>แถวแรกสุด (Row 1) จะถูกข้ามไป เพราะถือว่าเป็นส่วนหัวของตาราง (Header)</li>
            <li>ระบบจะตรวจสอบ `ItemCode` ที่ซ้ำกันและข้ามรายการนั้นไปโดยอัตโนมัติ</li>
        </ul>
    </div>

    <form action="import_items.php" method="post" enctype="multipart/form-data">
        <div>
            <label for="importFile" class="block text-sm font-medium text-gray-700">เลือกไฟล์ (Excel หรือ CSV)</label>
            <input type="file" name="importFile" id="importFile" accept=".xlsx, .csv" class="mt-1 block w-full text-sm text-gray-500
                file:mr-4 file:py-2 file:px-4
                file:rounded-md file:border-0
                file:text-sm file:font-semibold
                file:bg-indigo-50 file:text-indigo-700
                hover:file:bg-indigo-100" required>
        </div>
        <div class="mt-6">
            <button type="submit" class="py-2 px-4 rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                <svg class="inline-block w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>
                เริ่มการนำเข้า
            </button>
            <a href="items.php" class="ml-4 py-2 px-4 rounded-md text-gray-700 bg-gray-200 hover:bg-gray-300">กลับไปหน้ารายการ</a>
        </div>
    </form>
</div>


<?php 
// 6. เรียกใช้ Footer
require_once 'partials/footer.php'; 
?>
