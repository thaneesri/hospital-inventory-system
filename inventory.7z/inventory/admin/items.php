<?php
// File: /admin/items.php

require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

$message = ""; 

// --- จัดการ Action ต่างๆ ที่ส่งเข้ามา ---
// (ส่วนนี้ยังคงทำงานเหมือนเดิม ทั้งการเพิ่ม, แก้ไข, ลบ, และแสดงข้อความสถานะ)
if (isset($_GET['status']) && $_GET['status'] == 'updatesuccess') { 
    $message = "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4' role='alert'>แก้ไขข้อมูลสำเร็จ!</div>"; 
}
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $deleteResult = deleteItemById($conn, intval($_GET['id']));
    if ($deleteResult === true) {
        $message = "<div class='bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-4' role='alert'>ลบข้อมูลสำเร็จ!</div>";
    } else {
        $message = "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4' role='alert'>เกิดข้อผิดพลาด: " . htmlspecialchars($deleteResult) . "</div>";
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_item'])) {
    $itemData = [
        'itemCode'      => $_POST['itemCode'],
        'itemName'      => $_POST['itemName'],
        'category'      => $_POST['category'],
        'itemType'      => $_POST['itemType'],
        'formulation'   => $_POST['formulation'],
        'packageSize'   => $_POST['packageSize'],
        'strength'      => $_POST['strength'],
        'unit'          => $_POST['unit'],
        'price'         => $_POST['price'],
        'reorderPoint'  => $_POST['reorderPoint']
    ];
    $result = insertItem($conn, $itemData);
    if ($result === true) {
        $message = "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4' role='alert'>เพิ่มข้อมูลสำเร็จ!</div>";
    } else {
        $message = "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4' role='alert'>เกิดข้อผิดพลาด: " . htmlspecialchars($result) . "</div>";
    }
}

// --- ดึงข้อมูลทั้งหมดสำหรับ Datatable ---
$itemsResult = getAllItems($conn);
$stockTotals = getTotalStockGroupedByItem($conn);

$pageTitle = "จัดการข้อมูลยาและเวชภัณฑ์";
require_once 'partials/header.php';
?>

<!-- ส่วนปุ่มและฟอร์มเพิ่มข้อมูลที่ซ่อนไว้ -->
<div class="mb-8">
    <button id="toggleFormBtn" class="w-full sm:w-auto inline-flex justify-center py-2 px-4 border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
        + เพิ่มรายการใหม่
    </button>

    <div id="addItemForm" class="hidden bg-white p-6 rounded-lg shadow-md mt-4">
        <h2 class="text-xl font-semibold text-gray-700 mb-4">ฟอร์มเพิ่มรายการใหม่</h2>
        <?php echo $message; ?>
        <form action="items.php" method="post" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div><label class="block text-sm font-medium">รหัสสินค้า (คีย์หลัก)</label><input type="text" name="itemCode" class="mt-1 block w-full border-gray-300 rounded-md" required></div>
            <div><label class="block text-sm font-medium">ชื่อรายการ</label><input type="text" name="itemName" class="mt-1 block w-full border-gray-300 rounded-md" required></div>
            <div><label class="block text-sm font-medium">กลุ่มยา</label><input type="text" name="category" class="mt-1 block w-full border-gray-300 rounded-md"></div>
            <div>
                <label class="block text-sm font-medium text-gray-700">ประเภท</label>
                <div class="mt-2 flex space-x-4">
                    <div class="flex items-center">
                        <input id="add_type_drug" name="itemType" type="radio" value="ยา" checked class="h-4 w-4 text-indigo-600 border-gray-300">
                        <label for="add_type_drug" class="ml-2 block text-sm text-gray-900">ยา (drug)</label>
                    </div>
                    <div class="flex items-center">
                        <input id="add_type_nondrug" name="itemType" type="radio" value="เวชภัณฑ์" class="h-4 w-4 text-indigo-600 border-gray-300">
                        <label for="add_type_nondrug" class="ml-2 block text-sm text-gray-900">เวชภัณฑ์ (non-drug)</label>
                    </div>
                </div>
            </div>
            <div><label class="block text-sm font-medium">รูปแบบยา</label><input type="text" name="formulation" class="mt-1 block w-full border-gray-300 rounded-md"></div>
            <div><label class="block text-sm font-medium">ขนาดบรรจุ</label><input type="text" name="packageSize" class="mt-1 block w-full border-gray-300 rounded-md"></div>
            <div><label class="block text-sm font-medium">ความแรง</label><input type="text" name="strength" class="mt-1 block w-full border-gray-300 rounded-md"></div>
            <div><label class="block text-sm font-medium">หน่วยนับ</label><input type="text" name="unit" class="mt-1 block w-full border-gray-300 rounded-md" required></div>
            <div><label class="block text-sm font-medium">ราคา/หน่วย</label><input type="number" step="0.01" name="price" class="mt-1 block w-full border-gray-300 rounded-md" value="0"></div>
            <div><label class="block text-sm font-medium">จุดสั่งซื้อ</label><input type="number" name="reorderPoint" class="mt-1 block w-full border-gray-300 rounded-md" value="0"></div>
            <div class="lg:col-span-4"><button type="submit" name="add_item" class="py-2 px-4 rounded-md text-white bg-indigo-600 hover:bg-indigo-700">บันทึกข้อมูล</button></div>
        </form>
    </div>
</div>


<!-- ส่วนตารางแสดงผล Datatable -->
<div class="bg-white p-6 rounded-lg shadow-md">
    <div class="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-4">
        <h2 class="text-xl font-semibold text-gray-700">รายการยาและเวชภัณฑ์ทั้งหมด</h2>
        <div class="flex items-center gap-4">
            <a href="import_items.php" class="px-4 py-2 bg-green-600 text-white font-semibold rounded-md hover:bg-green-700 whitespace-nowrap">นำเข้าข้อมูล</a>
            <a href="../reports/export_handler.php?report_type=all_items" class="px-4 py-2 bg-teal-600 text-white font-semibold rounded-md hover:bg-teal-700 whitespace-nowrap">ส่งออกเป็น Excel</a>
        </div>
    </div>
    
    <div class="overflow-x-auto">
        <table id="itemsDataTable" class="min-w-full">
            <thead>
                <tr>
                    <th>ชื่อรายการ</th>
                    <th>รูปแบบยา</th>
                    <th>ขนาดบรรจุ</th>
                    <th class="text-right">คงเหลือ</th>
                    <th data-sortable="false" class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($itemsResult && $itemsResult->num_rows > 0) {
                    while($row = $itemsResult->fetch_assoc()) {
                        $currentStock = isset($stockTotals[$row['ItemID']]) ? $stockTotals[$row['ItemID']] : 0;
                        echo "<tr>";
                        echo "<td><div class='font-medium'>" . htmlspecialchars($row["ItemName"]) . "</div><div class='text-sm text-gray-500'>" . htmlspecialchars($row["ItemCode"]) . "</div></td>";
                        echo "<td>" . htmlspecialchars($row["Formulation"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["PackageSize"]) . "</td>";
                        echo "<td class='text-right font-bold'>" . number_format($currentStock) . " " . htmlspecialchars($row['Unit']) . "</td>";
                        echo "<td class='text-right text-sm'>";
                        echo "<a href='../stock/stock_card.php?id=" . $row['ItemID'] . "' class='text-blue-600 hover:underline mr-3'>สต็อกการ์ด</a>";
                        echo "<a href='edit_item.php?id=" . $row['ItemID'] . "' class='text-indigo-600 hover:underline mr-3'>แก้ไข</a>";
                        echo "<a href='items.php?action=delete&id=" . $row['ItemID'] . "' class='text-red-600 hover:underline' onclick=\"return confirm('ต้องการลบรายการนี้?');\">ลบ</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'partials/footer.php'; ?>

<!-- สคริปต์สำหรับ Datatable และซ่อนฟอร์ม -->
<link href="https://cdn.jsdelivr.net/npm/vanilla-datatables@latest/dist/vanilla-dataTables.min.css" rel="stylesheet" type="text/css">
<script src="https://cdn.jsdelivr.net/npm/vanilla-datatables@latest/dist/vanilla-dataTables.min.js" type="text/javascript"></script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        // --- ส่วนของ Datatable ---
        const dataTable = new DataTable("#itemsDataTable", {
            perPage: 15,
            labels: {
                placeholder: "ค้นหา...",
                perPage: "{select} รายการต่อหน้า",
                noRows: "ไม่พบข้อมูล",
                info: "แสดง {start} ถึง {end} จาก {rows} รายการ",
            }
        });

        // --- ส่วนของการซ่อน/แสดงฟอร์ม ---
        const toggleBtn = document.getElementById('toggleFormBtn');
        const addItemForm = document.getElementById('addItemForm');

        toggleBtn.addEventListener('click', function() {
            addItemForm.classList.toggle('hidden');
            // เปลี่ยนข้อความบนปุ่ม
            if (addItemForm.classList.contains('hidden')) {
                toggleBtn.innerHTML = '+ เพิ่มรายการใหม่';
            } else {
                toggleBtn.innerHTML = 'ซ่อนฟอร์ม';
            }
        });
    });
</script>
