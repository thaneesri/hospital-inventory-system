<?php
// File: /admin/users.php

require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

$message = ""; 

// จัดการข้อความสถานะที่ส่งกลับมาจากหน้าแก้ไข
if (isset($_GET['status']) && $_GET['status'] == 'updatesuccess') {
    $message = "<div class='bg-green-100 border-green-400 text-green-700 px-4 py-3 rounded' role='alert'>แก้ไขข้อมูลผู้ใช้สำเร็จ!</div>";
}

// จัดการเมื่อมีการกดลบ
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $deleteResult = deleteUserById($conn, intval($_GET['id']));
    if ($deleteResult === true) {
        $message = "<div class='bg-yellow-100 border-yellow-400 text-yellow-700 px-4 py-3 rounded' role='alert'>ลบผู้ใช้งานสำเร็จ!</div>";
    } else {
        $message = "<div class='bg-red-100 border-red-400 text-red-700 px-4 py-3 rounded' role='alert'>เกิดข้อผิดพลาด: " . htmlspecialchars($deleteResult) . "</div>";
    }
}

// จัดการเมื่อมีการกดเพิ่มผู้ใช้
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_user'])) {
    if ($_POST['password'] !== $_POST['confirm_password']) {
        $message = "<div class='bg-red-100 border-red-400 text-red-700 px-4 py-3 rounded' role='alert'>รหัสผ่านและการยืนยันไม่ตรงกัน!</div>";
    } else {
        $userData = [
            'fullName'  => $_POST['fullName'],
            'position'  => $_POST['position'],
            'userRole'  => $_POST['userRole'],
            'username'  => $_POST['username'],
            'password'  => $_POST['password']
        ];
        $result = insertUser($conn, $userData);
        if ($result === true) {
            $message = "<div class='bg-green-100 border-green-400 text-green-700 px-4 py-3 rounded' role='alert'>เพิ่มผู้ใช้งานสำเร็จ!</div>";
        } else {
            $message = "<div class='bg-red-100 border-red-400 text-red-700 px-4 py-3 rounded' role='alert'>เกิดข้อผิดพลาด: " . htmlspecialchars($result) . "</div>";
        }
    }
}

$usersResult = getAllUsers($conn);
$pageTitle = "จัดการข้อมูลผู้ใช้งาน";

require_once 'partials/header.php';
?>

<!-- Add Form Section -->
<div class="bg-white p-6 rounded-lg shadow-md mb-8">
    <h2 class="text-xl font-semibold text-gray-700 mb-4">เพิ่มผู้ใช้งานใหม่</h2>
    <?php echo $message; ?>
    <form action="users.php" method="post" class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label for="fullName" class="block text-sm font-medium text-gray-700">ชื่อ-สกุล</label>
            <input type="text" name="fullName" id="fullName" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm" required>
        </div>
        <div>
            <label for="position" class="block text-sm font-medium text-gray-700">ตำแหน่ง</label>
            <input type="text" name="position" id="position" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm">
        </div>
        <div>
            <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
            <input type="text" name="username" id="username" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm" required>
        </div>
        <div>
            <label for="userRole" class="block text-sm font-medium text-gray-700">สิทธิ์</label>
            <select name="userRole" id="userRole" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm">
                <option value="Requester">ผู้เบิก</option>
                <option value="Dispenser">ผู้จ่าย</option>
                <option value="Approver">ผู้อนุมัติ</option>
                <option value="Admin">ผู้ดูแลระบบ</option>
            </select>
        </div>
        <div>
            <label for="password" class="block text-sm font-medium text-gray-700">รหัสผ่าน</label>
            <input type="password" name="password" id="password" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm" required>
        </div>
        <div>
            <label for="confirm_password" class="block text-sm font-medium text-gray-700">ยืนยันรหัสผ่าน</label>
            <input type="password" name="confirm_password" id="confirm_password" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm" required>
        </div>
        <div class="md:col-span-2">
            <button type="submit" name="add_user" class="py-2 px-4 rounded-md text-white bg-indigo-600 hover:bg-indigo-700">บันทึกข้อมูลผู้ใช้งาน</button>
        </div>
    </form>
</div>

<!-- Table Section -->
<div class="bg-white rounded-lg shadow-md overflow-x-auto">
    <h2 class="text-xl font-semibold text-gray-700 mb-4 p-6">รายชื่อผู้ใช้งานทั้งหมด</h2>
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ชื่อ-สกุล</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Username</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">สิทธิ์</th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
            <?php
            if ($usersResult && $usersResult->num_rows > 0) {
                while($row = $usersResult->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td class='px-6 py-4 whitespace-nowrap text-sm'>" . htmlspecialchars($row["FullName"]) . "</td>";
                    echo "<td class='px-6 py-4 whitespace-nowrap text-sm'>" . htmlspecialchars($row["Username"]) . "</td>";
                    echo "<td class='px-6 py-4 whitespace-nowrap text-sm'>" . htmlspecialchars($row["UserRole"]) . "</td>";
                    echo "<td class='px-6 py-4 whitespace-nowrap text-right text-sm font-medium'>";
                    echo "<a href='edit_user.php?id=" . $row['UserID'] . "' class='text-indigo-600 hover:text-indigo-900 mr-3'>แก้ไข</a>";
                    echo "<a href='users.php?action=delete&id=" . $row['UserID'] . "' class='text-red-600 hover:text-red-900' onclick=\"return confirm('คุณแน่ใจหรือไม่ว่าต้องการลบผู้ใช้งานนี้?');\">ลบ</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4' class='text-center p-4 text-sm text-gray-500'>ยังไม่มีข้อมูลผู้ใช้งาน</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<?php
require_once 'partials/footer.php';
?>
