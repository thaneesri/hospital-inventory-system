<?php
// File: /admin/run_update.php

// 1. เรียกใช้ไฟล์ที่จำเป็นและตรวจสอบสิทธิ์
require_once '../includes/auth_check.php';
if ($_SESSION['user_role'] != 'Admin') { 
    die("Access Denied. You must be an administrator to perform this action."); 
}

// 2. ตั้งค่าพื้นฐานและป้องกัน timeout
set_time_limit(0); // ไม่จำกัดเวลาในการรันสคริปต์

// --- 3. ตั้งค่า GitHub Repository ของคุณ ---
// *** แก้ไข 2 บรรทัดนี้ให้เป็นของคุณ ***
$githubUser = 'thaneesri'; // <<-- แก้ไขเป็น Username ของคุณ
$githubRepo = 'hospital-inventory-system'; // <<-- แก้ไขเป็นชื่อ Repository ของคุณ

// --- 4. เริ่มกระบวนการและแสดงผล ---
echo "<!DOCTYPE html><html lang='th'><head><title>Update Process</title><meta charset='UTF-8'><style>body{font-family: sans-serif; padding: 2em;}</style></head><body>";
echo "<h1>กำลังเริ่มกระบวนการอัปเดต...</h1>";
flush(); // ส่ง output ไปยังเบราว์เซอร์ทันที

// 5. กำหนด Path ที่จะใช้งาน
$zipUrl = "https://github.com/{$githubUser}/{$githubRepo}/archive/refs/heads/main.zip";
$zipFile = __DIR__ . '/../update_package.zip'; // เก็บไฟล์ zip ไว้ที่โฟลเดอร์หลัก (inventory/)
$extractPath = __DIR__ . '/../'; // Path ที่จะแตกไฟล์และเขียนทับ

// 6. ดาวน์โหลดไฟล์ Zip จาก GitHub
echo "<p>กำลังดาวน์โหลดไฟล์จาก: " . htmlspecialchars($zipUrl) . "...</p>";
flush();
if (copy($zipUrl, $zipFile)) {
    echo "<p style='color:green;'>ดาวน์โหลดสำเร็จ!</p>";
    flush();

    // 7. แตกไฟล์ Zip
    $zip = new ZipArchive;
    if ($zip->open($zipFile) === TRUE) {
        echo "<p>กำลังแตกไฟล์...</p>";
        flush();
        // แตกไฟล์ไปยังโฟลเดอร์ชั่วคราว
        $tempExtractPath = $extractPath . 'update_temp/';
        if (!is_dir($tempExtractPath)) {
            mkdir($tempExtractPath, 0755, true);
        }
        $zip->extractTo($tempExtractPath);
        $zip->close();

        // ชื่อโฟลเดอร์ที่ได้จากการแตกไฟล์มักจะเป็น repo-main หรือ repo-master
        $sourceDir = $tempExtractPath . $githubRepo . '-main/';
        if (!is_dir($sourceDir)) {
             $sourceDir = $tempExtractPath . $githubRepo . '-master/';
        }
        
        // --- 8. ส่วนสำคัญ: ยกเว้นไฟล์ db_connect.php ---
        $dbConnectFileInSource = $sourceDir . 'includes/db_connect.php';
        if (file_exists($dbConnectFileInSource)) {
            unlink($dbConnectFileInSource);
            echo "<p style='color:orange;'><strong>ยกเว้นการอัปเดตไฟล์:</strong> includes/db_connect.php</p>";
            flush();
        }

        // 9. คัดลอกไฟล์ใหม่ไปทับไฟล์เก่า
        echo "<p>กำลังเขียนทับไฟล์โปรแกรม...</p>";
        flush();
        
        // ฟังก์ชันสำหรับคัดลอกไฟล์และโฟลเดอร์ทั้งหมด
        function recurse_copy($src, $dst) {
            $dir = opendir($src);
            @mkdir($dst);
            while(false !== ( $file = readdir($dir)) ) {
                if (( $file != '.' ) && ( $file != '..' )) {
                    if ( is_dir($src . '/' . $file) ) {
                        recurse_copy($src . '/' . $file, $dst . '/' . $file);
                    } else {
                        copy($src . '/' . $file, $dst . '/' . $file);
                    }
                }
            }
            closedir($dir);
        }

        recurse_copy($sourceDir, $extractPath);
        
        echo "<h2 style='color:green;'>อัปเดตเสร็จสมบูรณ์!</h2>";
        echo "<p><a href='updater.php'>กลับไปที่หน้าระบบอัปเดต</a> เพื่อตรวจสอบเวอร์ชันใหม่</p>";

        // 10. ลบไฟล์และโฟลเดอร์ชั่วคราว
        unlink($zipFile);
        // (ควรมีฟังก์ชันลบโฟลเดอร์ temp ด้วย แต่เพื่อความปลอดภัย ให้ลบเองก่อนในเบื้องต้น)

    } else {
        echo "<p style='color:red;'><strong>ข้อผิดพลาด:</strong> ไม่สามารถเปิดไฟล์ Zip ที่ดาวน์โหลดมาได้</p>";
    }
} else {
    echo "<p style='color:red;'><strong>ข้อผิดพลาด:</strong> ไม่สามารถดาวน์โหลดไฟล์จาก GitHub ได้ กรุณาตรวจสอบ URL และการเชื่อมต่อ</p>";
}
echo "</body></html>";
?>
