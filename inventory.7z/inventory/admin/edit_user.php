<?php
// File: /admin/edit_user.php

require_once '../includes/database_functions.php';

$message = "";

if (!isset($_GET['id'])) {
    header("Location: users.php");
    exit();
}
$userId = intval($_GET['id']);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_user'])) {
    // ตรวจสอบรหัสผ่าน (ถ้ามีการกรอก)
    if (!empty($_POST['password']) && $_POST['password'] !== $_POST['confirm_password']) {
        $message = "<div class='bg-red-100 border-red-400 text-red-700 px-4 py-3 rounded' role='alert'>รหัสผ่านใหม่และการยืนยันไม่ตรงกัน!</div>";
    } else {
        $userData = [
            'userId'    => $userId,
            'fullName'  => $_POST['fullName'],
            'position'  => $_POST['position'],
            'userRole'  => $_POST['userRole'],
            'username'  => $_POST['username'],
            'password'  => $_POST['password'] // ส่งไปทั้งค่าว่างและค่าใหม่
        ];

        $result = updateUser($conn, $userData);

        if ($result === true) {
            header("Location: users.php?status=updatesuccess");
            exit();
        } else {
            $message = "<div class='bg-red-100 border-red-400 text-red-700 px-4 py-3 rounded' role='alert'>เกิดข้อผิดพลาด: " . htmlspecialchars($result) . "</div>";
        }
    }
}

$user = getUserById($conn, $userId);
if (!$user) {
    header("Location: users.php");
    exit();
}

$pageTitle = "แก้ไขข้อมูลผู้ใช้: " . htmlspecialchars($user['FullName']);
require_once 'partials/header.php';
?>

<div class="bg-white p-6 rounded-lg shadow-md">
    <?php echo $message; ?>
    <form action="edit_user.php?id=<?php echo $userId; ?>" method="post" class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label for="fullName">ชื่อ-สกุล</label>
            <input type="text" name="fullName" id="fullName" value="<?php echo htmlspecialchars($user['FullName']); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
        </div>
        <div>
            <label for="position">ตำแหน่ง</label>
            <input type="text" name="position" id="position" value="<?php echo htmlspecialchars($user['Position']); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
        </div>
        <div>
            <label for="username">Username</label>
            <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($user['Username']); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
        </div>
        <div>
            <label for="userRole">สิทธิ์การใช้งาน</label>
            <select name="userRole" id="userRole" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                <option value="Requester" <?php if($user['UserRole'] == 'Requester') echo 'selected'; ?>>ผู้เบิก</option>
                <option value="Dispenser" <?php if($user['UserRole'] == 'Dispenser') echo 'selected'; ?>>ผู้จ่าย</option>
                <option value="Approver" <?php if($user['UserRole'] == 'Approver') echo 'selected'; ?>>ผู้อนุมัติ</option>
                <option value="Admin" <?php if($user['UserRole'] == 'Admin') echo 'selected'; ?>>ผู้ดูแลระบบ</option>
            </select>
        </div>
        <div class="md:col-span-2">
            <p class="text-sm text-gray-500">ทิ้งว่างไว้หากไม่ต้องการเปลี่ยนรหัสผ่าน</p>
        </div>
        <div>
            <label for="password">รหัสผ่านใหม่</label>
            <input type="password" name="password" id="password" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
        </div>
        <div>
            <label for="confirm_password">ยืนยันรหัสผ่านใหม่</label>
            <input type="password" name="confirm_password" id="confirm_password" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
        </div>
        <div class="md:col-span-2">
            <button type="submit" name="update_user" class="py-2 px-4 rounded-md text-white bg-indigo-600 hover:bg-indigo-700">บันทึกการแก้ไข</button>
            <a href="users.php" class="ml-4 py-2 px-4 rounded-md text-gray-700 bg-white hover:bg-gray-50 border">ยกเลิก</a>
        </div>
    </form>
</div>

<?php
require_once 'partials/footer.php';
?>
