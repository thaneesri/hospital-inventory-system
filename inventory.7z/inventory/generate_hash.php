<?php
// File: /inventory/generate_hash.php

// สคริปต์นี้ใช้สำหรับสร้างค่า Hash ของรหัสผ่าน
// เพื่อนำไปอัปเดตในฐานข้อมูลโดยตรง

// รหัสผ่านเริ่มต้นที่ต้องการสร้าง Hash
$passwordToHash = 'password';

// สร้าง Hash ด้วยอัลกอริทึมที่ปลอดภัย
$hashedPassword = password_hash($passwordToHash, PASSWORD_DEFAULT);

// แสดงผลค่า Hash ที่ได้
echo "Generated Hash for 'password':<br><br>";
echo "<textarea rows='3' cols='70' readonly>" . htmlspecialchars($hashedPassword) . "</textarea>";
?>
