<?php
// File: /index.php


// เริ่มต้น session เพื่อตรวจสอบสถานะการ login
session_start();

// ไม่ต้องบังคับ login ในหน้านี้ แต่ยังต้องเรียกใช้ไฟล์อื่น ๆ
require_once 'includes/db_connect.php';
require_once 'includes/database_functions.php';

// ดึงข้อมูลสำหรับ Dashboard
$pendingRequisitions = getPendingRequisitions($conn);
$lowStockItems = getLowStockItems($conn);
$nearExpiryItems = getNearExpiryItems($conn, 90); // แจ้งเตือนล่วงหน้า 90 วัน

$pageTitle = "Dashboard";
// เรียกใช้ header/footer จากโฟลเดอร์ admin
require_once 'admin/partials/header.php';
?>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    
    <!-- Card: รายการรออนุมัติ -->
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h3 class="text-lg font-semibold text-gray-700 mb-2">รายการรออนุมัติ</h3>
        <p class="text-3xl font-bold text-yellow-500"><?php echo $pendingRequisitions ? $pendingRequisitions->num_rows : 0; ?> <span class="text-base font-normal text-gray-500">รายการ</span></p>
        <?php 
        // --- ตรวจสอบว่า login และมีสิทธิ์ Approver หรือไม่ก่อนแสดงลิงก์ ---
        if (isset($_SESSION['user_id']) && ($_SESSION['user_role'] == 'Admin' || $_SESSION['user_role'] == 'Approver')): 
        ?>
            <a href="requisition/approve_requisitions.php" class="text-sm text-indigo-600 hover:underline mt-4 block">ไปที่หน้ารออนุมัติ &rarr;</a>
        <?php endif; ?>
    </div>

    <!-- Card: สินค้าใกล้หมด -->
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h3 class="text-lg font-semibold text-gray-700 mb-2">สินค้าใกล้หมด</h3>
        <p class="text-3xl font-bold text-red-500"><?php echo $lowStockItems ? $lowStockItems->num_rows : 0; ?> <span class="text-base font-normal text-gray-500">รายการ</span></p>
        <?php if (isset($_SESSION['user_id'])): // ตรวจสอบว่า login หรือไม่ก่อนแสดงลิงก์ ?>
            <a href="admin/items.php" class="text-sm text-indigo-600 hover:underline mt-4 block">ดูรายการทั้งหมด &rarr;</a>
        <?php endif; ?>
    </div>

    <!-- Card: สินค้าใกล้หมดอายุ -->
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h3 class="text-lg font-semibold text-gray-700 mb-2">สินค้าใกล้หมดอายุ (90 วัน)</h3>
        <p class="text-3xl font-bold text-orange-500"><?php echo $nearExpiryItems ? $nearExpiryItems->num_rows : 0; ?> <span class="text-base font-normal text-gray-500">รายการ</span></p>
        <!-- อาจจะสร้างหน้ารายงานโดยเฉพาะในอนาคต -->
        <a href="#" class="text-sm text-indigo-600 hover:underline mt-4 block">ดูรายละเอียด &rarr;</a>
    </div>

</div>

<?php
// เรียกใช้ footer
require_once 'admin/partials/footer.php';
?>
