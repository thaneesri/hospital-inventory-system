<?php
// File: /stock/receive_stock.php

require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

$message = "";
$parsedData = null;

// --- Action 1: จัดการการอัปโหลดไฟล์ (เพื่อแสดงหน้ายืนยัน) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["delivery_note_csv"])) {
    if (isset($_FILES["delivery_note_csv"]["error"]) && $_FILES["delivery_note_csv"]["error"] == UPLOAD_ERR_OK) {
        $filePath = $_FILES["delivery_note_csv"]["tmp_name"];
        $parsedData = parseDeliveryNoteCSV($conn, $filePath);
    } else {
        $message = "<div class='bg-red-100 p-3 rounded mb-6'>เกิดข้อผิดพลาดในการอัปโหลดไฟล์</div>";
    }
}

// --- Action 2: จัดการการยืนยันเพื่อบันทึกข้อมูลจากไฟล์ ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_import'])) {
    if (isset($_POST['items_to_import'])) {
        $itemsToImport = json_decode($_POST['items_to_import'], true);
        $importResult = ['success' => 0, 'errors' => 0];
        if (is_array($itemsToImport)) {
            foreach ($itemsToImport as $itemData) {
                $receiveResult = receiveStockItem($conn, $itemData);
                if ($receiveResult === true) {
                    $importResult['success']++;
                } else {
                    $importResult['errors']++;
                }
            }
        }
        $message = "<div class='bg-blue-100 p-4 rounded mb-6'><strong>บันทึกข้อมูลสำเร็จ!</strong><br>- เพิ่มสต็อกใหม่: " . $importResult['success'] . " รายการ<br>- พบข้อผิดพลาด: " . $importResult['errors'] . " รายการ</div>";
    }
}

// --- Action 3: จัดการการบันทึกทีละรายการ (Manual) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['receive_stock_manual'])) {
    $stockData = [
        'itemId'        => $_POST['itemId'],
        'lotNumber'     => $_POST['lotNumber'],
        'barcode'       => $_POST['barcode'],
        'expiryDate'    => $_POST['expiryDate'],
        'quantity'      => $_POST['quantity'],
        'purchasePrice' => $_POST['purchasePrice'],
        'subUnits'      => $_POST['subUnits']
    ];
    $result = receiveStockItem($conn, $stockData);
    if ($result === true) {
        $message = "<div class='bg-green-100 p-3 rounded'>บันทึกการรับของและคำนวณราคาเฉลี่ยใหม่สำเร็จ!</div>";
    } else {
        $message = "<div class='bg-red-100 p-3 rounded'>เกิดข้อผิดพลาด: " . htmlspecialchars($result) . "</div>";
    }
}


$itemsResult = getAllItems($conn);
$pageTitle = "รับของเข้าคลัง";
require_once '../admin/partials/header.php';
?>

<?php if ($parsedData): // --------- ถ้ามีข้อมูลที่อ่านได้ ให้แสดงหน้ายืนยัน --------- ?>

<div class="bg-white p-6 rounded-lg shadow-md max-w-6xl mx-auto">
    <h2 class="text-xl font-semibold mb-4">ตรวจสอบและยืนยันรายการนำเข้า</h2>
    <p class="text-sm text-gray-600 mb-4">กรุณาตรวจสอบความถูกต้องของข้อมูลด้านล่าง ระบบจะนำเข้าเฉพาะรายการที่ <span class="font-bold text-green-600">"พบข้อมูลในระบบ"</span> เท่านั้น</p>
    <form action="receive_stock.php" method="post">
        <?php
            $itemsToSave = array_filter($parsedData, function($row) {
                return $row['status'] == 'found';
            });
        ?>
        <input type="hidden" name="items_to_import" value="<?php echo htmlspecialchars(json_encode($itemsToSave)); ?>">
        <div class="overflow-x-auto border rounded-lg">
            <table class="min-w-full divide-y divide-gray-200">
                <!-- ... ตารางยืนยัน ... -->
            </table>
        </div>
        <div class="mt-6 flex justify-end gap-4">
            <a href="receive_stock.php" class="py-2 px-4 rounded-md border border-gray-300 bg-white text-gray-700 hover:bg-gray-50">ยกเลิก</a>
            <button type="submit" name="confirm_import" class="py-2 px-6 rounded-md text-white bg-indigo-600 hover:bg-indigo-700 font-bold">ยืนยันและบันทึกข้อมูล</button>
        </div>
    </form>
</div>

<?php else: // --------- ถ้ายังไม่มีข้อมูล ให้แสดงหน้าอัปโหลดและฟอร์ม Manual --------- ?>

<!-- ส่วนนำเข้าจากไฟล์ -->
<div class="bg-white p-6 rounded-lg shadow-md max-w-4xl mx-auto">
    <div class="mb-6 border-b pb-4">
        <h2 class="text-xl font-semibold">นำเข้าข้อมูลจากใบส่งของ (Excel)</h2>
        <ol class="list-decimal list-inside mt-2 text-gray-600 space-y-1 text-sm">
            <li>เตรียมไฟล์ Excel ให้มีคอลัมน์ตามลำดับดังนี้: <strong>ItemCode, LotNumber, ExpiryDate (YYYY-MM-DD), Quantity, PurchasePrice, SubUnits, Barcode (ถ้ามี)</strong></li>
            <li>บันทึกไฟล์เป็นชนิด <strong>CSV UTF-8 (Comma delimited) (.csv)</strong></li>
        </ol>
    </div>
    <?php if(isset($_FILES["delivery_note_csv"])) { echo $message; } ?>
    <form action="receive_stock.php" method="post" enctype="multipart/form-data">
        <div>
            <label for="delivery_note_csv" class="block text-sm font-medium text-gray-700">เลือกไฟล์ CSV ใบส่งของ</label>
            <input type="file" name="delivery_note_csv" id="delivery_note_csv" accept=".csv" class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" required>
        </div>
        <div class="mt-6">
            <button type="submit" class="w-full sm:w-auto py-2 px-4 rounded-md text-white bg-indigo-600 hover:bg-indigo-700">อัปโหลดและตรวจสอบข้อมูล</button>
        </div>
    </form>
</div>

<!-- ส่วนบันทึกทีละรายการ (ซ่อนไว้) -->
<div class="max-w-4xl mx-auto mt-8">
    <button id="toggleManualFormBtn" class="text-indigo-600 hover:underline text-sm mb-4">
        + หรือบันทึกทีละรายการ
    </button>
    <div id="manualReceiveForm" class="hidden bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-semibold mb-4">บันทึกทีละรายการ</h2>
        <?php if(isset($_POST['receive_stock_manual'])) { echo $message; } ?>
        <form action="receive_stock.php" method="post" class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="md:col-span-2">
                <label for="itemId" class="block text-sm font-medium text-gray-700">เลือกรายการยา/เวชภัณฑ์</label>
                <select name="itemId" id="itemId" class="mt-1 block w-full border-gray-300 rounded-md" required>
                    <option value="">--- กรุณาเลือก ---</option>
                    <?php
                    if ($itemsResult && $itemsResult->num_rows > 0) {
                        mysqli_data_seek($itemsResult, 0); // Reset pointer
                        while($item = $itemsResult->fetch_assoc()) {
                            echo "<option value='" . $item['ItemID'] . "'>" . htmlspecialchars($item['ItemName']) . " (" . htmlspecialchars($item['ItemCode']) . ")</option>";
                        }
                    }
                    ?>
                </select>
            </div>
            <div>
                <label for="lotNumber" class="block text-sm font-medium text-gray-700">Lot Number</label>
                <input type="text" name="lotNumber" id="lotNumber" class="mt-1 block w-full border-gray-300 rounded-md" required>
            </div>
            <div>
                <label for="barcode">Barcode / QR Code (ถ้ามี)</label>
                <input type="text" name="barcode" id="barcode" class="mt-1 block w-full border-gray-300 rounded-md">
            </div>
            <div>
                <label for="expiryDate" class="block text-sm font-medium text-gray-700">วันหมดอายุ</label>
                <input type="date" name="expiryDate" id="expiryDate" class="mt-1 block w-full border-gray-300 rounded-md">
            </div>
            <div>
                <label for="quantity" class="block text-sm font-medium text-gray-700">จำนวนที่รับเข้า (หน่วยใหญ่)</label>
                <input type="number" name="quantity" id="quantity" min="1" class="mt-1 block w-full border-gray-300 rounded-md" required>
            </div>
            <div>
                <label for="purchasePrice" class="block text-sm font-medium text-gray-700">ราคาซื้อจริง (ต่อหน่วยใหญ่)</label>
                <input type="number" step="0.01" name="purchasePrice" id="purchasePrice" min="0" class="mt-1 block w-full border-gray-300 rounded-md" required>
            </div>
            <div class="md:col-span-2">
                <label for="subUnits" class="block text-sm font-medium text-gray-700">จำนวนหน่วยย่อยต่อหน่วยใหญ่</label>
                <input type="number" name="subUnits" id="subUnits" min="1" class="mt-1 block w-full border-gray-300 rounded-md" required>
                <p class="text-xs text-gray-500 mt-1">เช่น ยา 1 กล่อง มี 100 เม็ด ให้ใส่ 100</p>
            </div>
            <div class="md:col-span-2">
                <button type="submit" name="receive_stock_manual" class="w-full sm:w-auto py-2 px-4 rounded-md text-white bg-indigo-600 hover:bg-indigo-700">บันทึกการรับของ</button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const toggleBtn = document.getElementById('toggleManualFormBtn');
    const manualForm = document.getElementById('manualReceiveForm');
    toggleBtn.addEventListener('click', function() {
        manualForm.classList.toggle('hidden');
        if (!manualForm.classList.contains('hidden')) {
            toggleBtn.textContent = '- ซ่อนฟอร์มบันทึกทีละรายการ';
        } else {
            toggleBtn.textContent = '+ หรือบันทึกทีละรายการ';
        }
    });
});
</script>

<?php endif; ?>

<?php
require_once '../admin/partials/footer.php';
?>
