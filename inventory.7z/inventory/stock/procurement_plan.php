<?php
// File: /stock/procurement_plan.php

// 1. เรียกใช้ไฟล์ที่จำเป็น
require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

$message = "";
// 2. ตรวจสอบว่ามีการเลือกดูแผนจาก URL หรือไม่
$currentPlanId = isset($_GET['plan_id']) ? intval($_GET['plan_id']) : null;
$planDetails = null;
$planInfo = null;

// --- 3. จัดการ Action ต่างๆ ที่ส่งเข้ามา ---

// Action: สร้างแผนใหม่
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['generate_plan'])) {
    // คำนวณอัตราการใช้ล่าสุดก่อน
    calculateAndStoreAverageUsage($conn);
    
    $planName = "แผนจัดซื้อ " . date("d-m-Y H:i");
    $newPlanId = generateProcurementPlan($conn, $planName, $_SESSION['user_id']);

    if (is_numeric($newPlanId)) {
        // สร้างสำเร็จ ให้ redirect ไปยังหน้าดูรายละเอียดแผนใหม่ทันที
        header("Location: procurement_plan.php?plan_id=" . $newPlanId . "&status=created");
        exit();
    } else {
        $message = "<div class='bg-red-100 p-3 rounded'>เกิดข้อผิดพลาด: " . htmlspecialchars($newPlanId) . "</div>";
    }
}

// Action: บันทึกการแก้ไขแผน
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_plan'])) {
    $planIdToSave = intval($_POST['plan_id']);
    $actualQuantities = $_POST['actual_quantity'];
    $result = updateProcurementPlanItems($conn, $planIdToSave, $actualQuantities);
    if ($result === true) {
        $message = "<div class='bg-green-100 p-3 rounded'>บันทึกการแก้ไขแผนสำเร็จ!</div>";
        $currentPlanId = $planIdToSave; // กำหนด plan id เพื่อให้แสดงผลแผนที่เพิ่งบันทึก
    } else {
        $message = "<div class='bg-red-100 p-3 rounded'>เกิดข้อผิดพลาด: " . htmlspecialchars($result) . "</div>";
    }
}

// --- 4. ดึงข้อมูลมาแสดงผล ---
// แสดงข้อความหลังจากสร้างแผนสำเร็จ
if (isset($_GET['status']) && $_GET['status'] == 'created') {
    $message = "<div class='bg-green-100 p-3 rounded'>สร้างแผนการจัดซื้อใหม่สำเร็จ!</div>";
}

// ดึงรายละเอียดแผนที่กำลังดู (ถ้ามี)
if ($currentPlanId) {
    $planDetails = getProcurementPlanDetails($conn, $currentPlanId);
    // (Optional) ดึงข้อมูลหลักของแผน เช่น ชื่อ, วันที่
    $planInfoStmt = $conn->prepare("SELECT * FROM ProcurementPlans WHERE PlanID = ?");
    $planInfoStmt->bind_param("i", $currentPlanId);
    $planInfoStmt->execute();
    $planInfo = $planInfoStmt->get_result()->fetch_assoc();
    $planInfoStmt->close();
}

// ดึงประวัติแผนทั้งหมด
$allPlans = getAllProcurementPlans($conn);

$pageTitle = "วางแผนการจัดซื้อ";
require_once '../admin/partials/header.php';
?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <!-- คอลัมน์ซ้าย: สร้างแผนและประวัติ -->
    <div class="lg:col-span-1 space-y-8">
        <!-- ส่วนสร้างแผนใหม่ -->
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold text-gray-700 mb-2">สร้างแผนใหม่</h2>
            <p class="text-gray-600 text-sm mb-4">ระบบจะคำนวณอัตราการใช้ย้อนหลัง 3 เดือน และสร้างแผนฉบับร่างให้อัตโนมัติ</p>
            <form action="procurement_plan.php" method="post">
                <button type="submit" name="generate_plan" class="w-full py-2 px-4 rounded-md text-white bg-indigo-600 hover:bg-indigo-700" onclick="return confirm('ยืนยันการสร้างแผนใหม่? การดำเนินการนี้จะคำนวณข้อมูลการใช้ยาทั้งหมดใหม่');">
                    คำนวณและสร้างแผนใหม่
                </button>
            </form>
        </div>

        <!-- ส่วนประวัติแผน -->
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h3 class="text-lg font-semibold">ประวัติแผนการจัดซื้อ</h3>
            <ul class="divide-y divide-gray-200 mt-4 max-h-96 overflow-y-auto">
                <?php if ($allPlans && $allPlans->num_rows > 0): ?>
                    <?php while($plan = $allPlans->fetch_assoc()): ?>
                        <li class="py-2">
                            <a href="?plan_id=<?php echo $plan['PlanID']; ?>" class="block hover:bg-gray-50 p-2 rounded-md <?php echo ($currentPlanId == $plan['PlanID']) ? 'bg-indigo-50' : ''; ?>">
                                <p class="font-medium text-indigo-700"><?php echo htmlspecialchars($plan['PlanName']); ?></p>
                                <p class="text-sm text-gray-500">สร้างเมื่อ: <?php echo date("d/m/Y", strtotime($plan['PlanDate'])); ?></p>
                            </a>
                        </li>
                    <?php endwhile; ?>
                <?php else: ?>
                    <li class="text-center text-gray-500 py-4">ยังไม่มีประวัติ</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <!-- คอลัมน์ขวา: แสดงรายละเอียดแผน -->
    <div class="lg:col-span-2">
        <div class="bg-white p-6 rounded-lg shadow-md min-h-full">
            <?php if ($currentPlanId && $planDetails && $planInfo): ?>
                <h2 class="text-xl font-semibold mb-1">รายละเอียดแผน: <?php echo htmlspecialchars($planInfo['PlanName']); ?></h2>
                <p class="text-sm text-gray-500 mb-4">สถานะ: <span class="font-medium"><?php echo htmlspecialchars($planInfo['Status']); ?></span></p>
                <?php echo $message; ?>
                <form action="procurement_plan.php?plan_id=<?php echo $currentPlanId; ?>" method="post">
                    <input type="hidden" name="plan_id" value="<?php echo $currentPlanId; ?>">
                    <div class="overflow-x-auto border rounded-lg">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">รายการ</th>
                                    <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">คงเหลือ</th>
                                    <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">ใช้เฉลี่ย/เดือน</th>
                                    <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">ยอดแนะนำ</th>
                                    <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase w-32">ยอดสั่งซื้อจริง</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                            <?php while($item = $planDetails->fetch_assoc()): ?>
                                <tr>
                                    <td class="px-4 py-2 font-medium text-sm text-gray-800"><?php echo htmlspecialchars($item['ItemName']); ?></td>
                                    <td class="px-4 py-2 text-right text-sm"><?php echo number_format($item['CurrentStock']); ?></td>
                                    <td class="px-4 py-2 text-right text-sm"><?php echo number_format($item['AvgMonthlyUsage'], 2); ?></td>
                                    <td class="px-4 py-2 text-right text-sm font-bold text-blue-600"><?php echo number_format($item['SuggestedQuantity']); ?></td>
                                    <td class="px-4 py-2">
                                        <input type="number" name="actual_quantity[<?php echo $item['PlanItemID']; ?>]" 
                                               value="<?php echo htmlspecialchars($item['ActualQuantity'] ?? $item['SuggestedQuantity']); ?>"
                                               class="w-full border-gray-300 rounded-md text-right shadow-sm text-sm">
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-6 text-right">
                        <button type="submit" name="save_plan" class="py-2 px-4 rounded-md text-white bg-green-600 hover:bg-green-700">
                            บันทึกการแก้ไขแผน
                        </button>
                    </div>
                </form>
            <?php else: ?>
                <div class="text-center flex items-center justify-center h-full">
                    <div>
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                            <path vector-effect="non-scaling-stroke" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h14a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
                        </svg>
                        <h3 class="mt-2 text-lg font-medium text-gray-700">กรุณาสร้างแผนใหม่ หรือเลือกแผนจากประวัติ</h3>
                        <p class="mt-1 text-sm text-gray-500">เพื่อดูรายละเอียดและแก้ไขยอดสั่งซื้อ</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
require_once '../admin/partials/footer.php';
?>
