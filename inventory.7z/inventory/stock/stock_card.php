<?php
// File: /stock/stock_card.php

require_once '../includes/auth_check.php';
require_once '../includes/database_functions.php';

if (!isset($_GET['id'])) {
    header("Location: ../admin/items.php");
    exit();
}

$itemId = intval($_GET['id']);
$item = getItemById($conn, $itemId);

if (!$item) {
    header("Location: ../admin/items.php");
    exit();
}

$stockHistory = getItemStockHistory($conn, $itemId);

$pageTitle = "สต็อกการ์ด: " . htmlspecialchars($item['ItemName']);
require_once '../admin/partials/header.php';
?>

<div class="bg-white p-6 rounded-lg shadow-md">
    <div class="mb-4">
        <h2 class="text-xl font-semibold">รายการ: <?php echo htmlspecialchars($item['ItemName']); ?></h2>
        <p class="text-sm text-gray-600">รหัส: <?php echo htmlspecialchars($item['ItemCode']); ?></p>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">วันที่</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ประเภทรายการ</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lot Number</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">วันหมดอายุ</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">จำนวน</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php
                if ($stockHistory && $stockHistory->num_rows > 0) {
                    while($row = $stockHistory->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm'>" . date("d/m/Y H:i", strtotime($row['ReceivedDate'])) . "</td>";
                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium'>รับเข้า</td>";
                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm'>" . htmlspecialchars($row['LotNumber']) . "</td>";
                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm'>" . ($row['ExpiryDate'] ? date("d/m/Y", strtotime($row['ExpiryDate'])) : '-') . "</td>";
                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-right'>+" . number_format($row['Quantity']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center p-4 text-sm text-gray-500'>ยังไม่มีประวัติความเคลื่อนไหว</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php
require_once '../admin/partials/footer.php';
?>
