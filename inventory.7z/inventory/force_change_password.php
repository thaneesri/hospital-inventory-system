<?php
// File: /force_change_password.php

session_start();

// ถ้ายังไม่ login หรือ ไม่ได้ถูกบังคับให้เปลี่ยน ก็ไม่ต้องเข้ามาหน้านี้
if (!isset($_SESSION['user_id']) || $_SESSION['must_change_password'] != 1) {
    header("Location: index.php");
    exit();
}

require_once 'includes/database_functions.php';
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    if (empty($newPassword) || $newPassword !== $confirmPassword) {
        $message = "<div class='bg-red-100 p-3 rounded mb-4'>รหัสผ่านใหม่และการยืนยันไม่ตรงกัน!</div>";
    } else {
        $result = updatePasswordAndFlag($conn, $_SESSION['user_id'], $newPassword);
        if ($result === true) {
            // สำเร็จแล้ว ส่งไปหน้า Dashboard
            header("Location: index.php");
            exit();
        } else {
            $message = "<div class='bg-red-100 p-3 rounded mb-4'>เกิดข้อผิดพลาด: " . htmlspecialchars($result) . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>เปลี่ยนรหัสผ่าน</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Sarabun', sans-serif; } </style>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="w-full max-w-md bg-white rounded-lg shadow-md p-8">
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-2">ตั้งรหัสผ่านใหม่</h2>
        <p class="text-center text-gray-600 mb-6">เพื่อความปลอดภัย กรุณาตั้งรหัสผ่านใหม่ก่อนเข้าใช้งานครั้งแรก</p>
        <?php echo $message; ?>
        <form action="force_change_password.php" method="post">
            <div class="mb-4">
                <label for="new_password" class="block text-gray-700 text-sm font-bold mb-2">รหัสผ่านใหม่</label>
                <input type="password" name="new_password" id="new_password" class="shadow border rounded w-full py-2 px-3" required>
            </div>
            <div class="mb-6">
                <label for="confirm_password" class="block text-gray-700 text-sm font-bold mb-2">ยืนยันรหัสผ่านใหม่</label>
                <input type="password" name="confirm_password" id="confirm_password" class="shadow border rounded w-full py-2 px-3" required>
            </div>
            <button type="submit" name="change_password" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded w-full">บันทึกรหัสผ่านใหม่</button>
        </form>
    </div>
</body>
</html>
